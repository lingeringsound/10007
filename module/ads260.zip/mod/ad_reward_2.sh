source "${0%/*}/ad_reward.sh"
#允许广告奖励
#Switch_ad_reward "allow"
#禁用广告奖励
#Switch_ad_reward

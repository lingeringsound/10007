id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

function show_value() {
	local value=$1
	local file="$MODPATH/配置.prop"
	test ! -f "$file" && file="$MODPATH/配置.conf"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}


all_file="${MODPATH}/Host/all"
all_count="`cat ${all_file} | wc -l`"
reward_file="${MODPATH}/Host/reward"
reward_count="`cat ${reward_file} | wc -l`"


for file in $(find "$MODPATH" -iname "hosts" -type f -type f 2>/dev/null)
do
target="`cat "${file}" | wc -l`"
if test "$(show_value '广告奖励')" = "否" ;then
	echo "All: ${all_count}\nTARGET: ${target}"
	[[ "${all_count}" != "${target}" ]] && cp -rf "${all_file}" "${file}"
else
	echo "Reward: ${all_count}\nTARGET: ${target}"
	[[ "${reward_count}" != "${target}" ]] && cp -rf "${reward_file}" "${file}"
fi
done





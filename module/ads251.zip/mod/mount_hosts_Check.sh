id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

Running_bin="${MODPATH}/mod/mount_hosts/mount_hosts"
Running_config="${MODPATH}/mod/mount_hosts/配置包名.prop"

test ! -f "${Running_bin}" && exit 0
source $MODPATH/mod/util_functions.sh

if test "$(show_value 'MountHost')" = "禁用" ;then
	exit 0
fi

wait_until_login() {
	# in case of /data encryption is disabled
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 1
	done
	# we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
	a="0"
	local test_file="/data/media/0/Android/data"
	while [ ! -e "${test_file}" ]; do
		a="$(($a + 1))"
		test "$a" = "3" && break
		sleep 3m
	done
}

wait_until_login

if ! dumpsys -l | grep 'cpuinfo' >/dev/null 2>&1 ;then
	Log_10007_dmesg "@10007 dumpsys service cpuinfo does not exist" "E"
else
a="1"
until $(dumpsys cpuinfo | grep 'mount_hosts' >/dev/null 2>&1)
do
	test "${a}" = "3" && break
	a="$(($a + 1))"
	sleep 5m
done
Check_cpuinfo="$(dumpsys cpuinfo | grep -Eo '[0-9]{1,3}(\.[0-9])?%[[:space:]]+[0-9]{1,6}\/mount_hosts' | sed -E 's|[[:space:]][0-9]{1,6}/mount_hosts||g')"
case "${Check_cpuinfo}" in
0.[0-9]%|0%)
	echo "正常"
;;
[0-9]%|[0-9].[0-9]%)
	echo "占用过大"
;;
[0-9][0-9]%|[0-9][0-9].[0-9]%)
	killall -9 mount_hosts >/dev/null 2>&1
	echo "异常占用！"
	Log_10007_dmesg "@10007 mount_hosts Running wrong" "E"
;;
esac
fi


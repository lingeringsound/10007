#/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH


function X_file() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function RE_file() {
	if test -e "$1"; then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}

function clear_BrowserMetrics_dir() {
	find /data/user /data/data /data/media -iname "*BrowserMetrics*" -type d 2>/dev/null | while read BrowserMetrics ;do
		X_file $BrowserMetrics
		echo "$BrowserMetrics" >>$MODPATH/Browser.log
	done
}

function clear_BrowserMetrics_file() {
	find /data/user /data/data /data/media -iname "*BrowserMetrics*" -type f 2>/dev/null | while read BrowserMetricsfile ;do
		rm -rf $BrowserMetricsfile 2>/dev/null
		echo "$BrowserMetricsfile" >>$MODPATH/Browser.log
	done
}

clear_BrowserMetrics_dir
clear_BrowserMetrics_file

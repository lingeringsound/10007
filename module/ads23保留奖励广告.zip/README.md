## 去广告
### 啥也不是？
#### 版本更新日志
### [源地址：如果有帮助，请您支持我一下😘！](https://gitee.com/keytoolazy/mapdepot )
![赞赏码](https://gitee.com/keytoolazy/mapdepot/raw/master/%E8%B5%9E%E8%B5%8F%E7%A0%81.png)

- **说明**
> 模块hosts冲突 
>> 模块刷入的时候不存在hosts冲突，因为会自动合并当前存在的hosts模块 
>>> chattr 
>>>> 如果遇到文件异常无法写入，请尝试执行模块`uninstall.sh`，未安装模块，直接用 **[mt文件管理器执行](https://binmt.lanzoui.com/b01bivkzc)** `uninstall.sh` 也可解决。

 - v6
 > 低估了酷安的恶心程度
 - v7
 > 修复京东闲置回收无法打开的bug
 - v8
 > 添加完整的卸载脚本uninstall.sh
 - v9
 > 合并[NEO DEV Team](https://github.com/neodevpro/neodevhost) 的广告拦截
 - v11
 > 日常更新host
 > 支⃠持⃠在⃠线⃠更⃠新⃠(个屁)
 - v12
 > 取消合并[NEO DEV Team](https://github.com/neodevpro/neodevhost)
 > 更新酷安的禁用规则
 > 字节跳动的所有软件亦可正常使用，不再拦截如`今日头条`，`皮皮虾`，`抖音`。
 - v13
 > 添加`ad`和`ads`域名拦截
 - v14
 > 日常更新host
 > 添加`adnet`(chattr屏蔽)
 - v15
 > 添加关键词`adsdk`的host屏蔽
 - v16
 > 添加关键词`cnzz`的host屏蔽
 - v17
 > 更新host规则
 > 更新酷安规则
 - v18
 > 取消屏蔽`Flyme`
 - v19
 > 取消屏蔽`QQ直播`
 > 取消屏蔽`X5内核下载`
 - v20
 > 修复部分host误杀
 - v21
 > 添加`doubleclick`和`googleads`域名的拦截
 > 修复`MIUI应用禁用组件`脚本的一些报错。
 - v22
 > 尝试屏蔽`Flyme(MEIZU)`系统的一些广告，`Flyme`的用户可以反馈一下。
 > 添加`adapi`和`adsapi`相关域名屏蔽。
 - v23
 > ①兄弟姐妹们，坏消息，我刚刚不小心删库了😨，之前抓的host没了😂。
 > ②好消息就是，对不起，没有好消息🙄③我凭借印象又抓了一遍，所以如果遇到误杀，请及时反馈🤔！
 > ③添加了**微信广告**的地址拦截。

list="
ikhgg.snalkdl.top
www.googleadservices.com
googleadservices.com
ad.doubleclick.net
ads.pointroll.com
ad-emea.doubleclick.net
static.doubleclick.net
doubleclick.net
302br.net
"

for i in $list ;do
#禁用网址和子域名
iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
#iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done 


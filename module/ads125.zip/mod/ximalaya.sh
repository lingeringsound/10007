#!/system/bin/sh

function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
MOCK_LOCATION
MONITOR_HIGH_POWER_LOCATION
FINE_LOCATION
MONITOR_LOCATION
WAKE_LOCK
WRITE_EXTERNAL_STORAGE
READ_PHONE_STATE
SYSTEM_ALERT_WINDOW
TOAST_WINDOW
VIBRATE
READ_CALENDAR
WRITE_CALENDAR
READ_DEVICE_IDENTIFIERS
CHANGE_WIFI_STATE
LEGACY_STORAGE
"
for ops in $list 
do
	cmd appops set $package $ops $action
done
}

deny_appops "com.ximalaya.ting.android" "ignore"


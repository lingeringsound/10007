#!/system/bin

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

#disable 代表禁用
#enable 代表启用
sate=disable 

disable_list='
com.coolapk.market/com.beizi.ad.AdActivity
com.coolapk.market/com.beizi.ad.DownloadService
com.coolapk.market/com.bytedance.applog.migrate.MigrateDetectorActivity
com.coolapk.market/com.bytedance.novel.channel.NovelWebActivity
com.coolapk.market/com.bytedance.novel.view.NovelReaderActivity
com.coolapk.market/com.bytedance.sdk.open.douyin.ui.DouYinWebAuthorizeActivity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity_T
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity_T
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Landscape_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Portrait_Activity
com.coolapk.market/com.heytap.msp.push.service.CompatibleDataMessageCallbackService
com.coolapk.market/com.heytap.msp.push.service.DataMessageCallbackService
com.coolapk.market/com.huawei.agconnect.core.ServiceDiscovery
com.coolapk.market/com.kepler.jd.sdk.KeplerBackActivity
com.coolapk.market/com.kwad.sdk.api.proxy.VideoWallpaperService
com.coolapk.market/com.kwad.sdk.api.proxy.app.AdWebViewActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ChannelDetailActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$DeveloperConfigActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$EpisodeDetailActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity1
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity10
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity2
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity3
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity4
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity5
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity6
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity7
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity8
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity9
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleInstance1
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleInstance2
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleTop1
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleTop2
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$GoodsPlayBackActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$KsTrendsActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ProfileHomeActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ProfileVideoDetailActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$TubeDetailActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$TubeProfileActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.DownloadService
com.coolapk.market/com.kwad.sdk.api.proxy.app.FeedDownloadActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.FileDownloadService$SeparateProcessService
com.coolapk.market/com.kwad.sdk.api.proxy.app.FileDownloadService$SharedMainProcessService
com.coolapk.market/com.kwad.sdk.api.proxy.app.KSRewardLandScapeVideoActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.KsFullScreenLandScapeVideoActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.KsFullScreenVideoActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.KsRewardVideoActivity
com.coolapk.market/com.kwad.sdk.api.proxy.app.ServiceProxyRemote
com.coolapk.market/com.miui.zeus.mimo.sdk.ad.reward.RewardVideoAdActivity
com.coolapk.market/com.qq.e.ads.ADActivity
com.coolapk.market/com.qq.e.ads.DialogActivity
com.coolapk.market/com.qq.e.ads.LandscapeADActivity
com.coolapk.market/com.qq.e.ads.PortraitADActivity
com.coolapk.market/com.qq.e.ads.RewardvideoLandscapeADActivity
com.coolapk.market/com.qq.e.ads.RewardvideoPortraitADActivity
com.coolapk.market/com.qq.e.comm.DownloadService
com.coolapk.market/com.ss.android.downloadlib.activity.TTDelegateActivity
com.coolapk.market/com.ss.android.socialbase.appdownloader.DownloadHandlerService
com.coolapk.market/com.ss.android.socialbase.appdownloader.RetryJobSchedulerService
com.coolapk.market/com.ss.android.socialbase.downloader.downloader.DownloadService
com.coolapk.market/com.ss.android.socialbase.downloader.downloader.SqlDownloadCacheService
com.coolapk.market/com.ss.android.socialbase.downloader.impls.DownloadHandleService
com.coolapk.market/com.ss.android.socialbase.downloader.notification.DownloadNotificationService
com.coolapk.market/com.tencent.tpns.mqttchannel.services.MqttService



'

for i in $disable_list 
do
pm $sate $i >/dev/null 2>&1
done

function X_file() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function RE_file() {
	if test -e "$1"; then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}


find /data/user/*/com.coolapk.market /data/data/com.coolapk.market /data/media/*/Android/data/com.coolapk.market -iname "tad_cache" -type d -o -iname "app_ad" -type d -o -iname "TTCache" -type d -o -iname "app_ad" -type d -o -iname "cachett_ad" -type d -o -iname "splash_image" -type d -o -iname "tt_tmpl_pkg" -type d -o -iname "com_qq_e_download" -type d -o -iname "pangle_com.byted.pangle" -type d 2>/dev/null | while read adfile ;do
	X_file $adfile
done



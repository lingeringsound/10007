list="
#谷歌和doubleclick广告
doubleclick.net
#admaster
admaster.com.cn
#囧次元
116.205.193.167
211.157.171.237
211.151.146.65
#迅雷
#x-api-shoulei.xunlei.com
#x.xunlei.com
#作业帮
httpdns.zybang.com
"
local IFS=$'\n'

for i in ${list}
do

if test "$(echo "${i}" | grep '^#')" != "" ;then
	continue
elif test "$(echo "${i}" | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}')" != "" ;then
	iptables -D OUTPUT -d "${i}" -j DROP >/dev/null 2>&1
	iptables -A OUTPUT -d "${i}" -j DROP
#	iptables -D OUTPUT -d "${i}" -j DROP
elif test "$(echo "${i}" | grep -E '^\*\.')" != "" ;then
	iptables -D OUTPUT -m tls --tls-host "${i}" -j DROP >/dev/null 2>&1
	iptables -A OUTPUT -m tls --tls-host "${i}" -j DROP
#	iptables -D OUTPUT -m tls --tls-host "${i}" -j DROP
else
	iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP >/dev/null 2>&1
	iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
#	iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
fi

done 


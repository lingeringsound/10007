
disable_list='
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$RequestInstallPermissionActivity
com.mfcloudcalculate.networkdisk/com.qq.e.comm.GDTFileProvider
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.SdkInterstitialActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.GdtPrivacyActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.MeishuDownloadDetailActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.MeishuRewardVideoPlayerActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.MeishuWebviewActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.core.webview.TaskCenterWebActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.meishu_ad.view.DownLoadDialogActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.MeishuAlertDialogActivity
com.mfcloudcalculate.networkdisk/com.meishu.sdk.activity.MeishuDetailActivity
com.mfcloudcalculate.networkdisk/com.beizi.ad.DownloadService
com.mfcloudcalculate.networkdisk/com.baidu.mobads.sdk.api.BdFileProvider
com.mfcloudcalculate.networkdisk/com.baidu.mobads.sdk.api.AppActivity
com.mfcloudcalculate.networkdisk/com.baidu.mobads.sdk.api.MobRewardVideoActivity
com.mfcloudcalculate.networkdisk/com.baidu.mobads.sdk.api.MobCPUDramaActivity
com.mfcloudcalculate.networkdisk/com.baidu.mobads.sdk.api.BdShellActivity
com.mfcloudcalculate.networkdisk/com.qq.e.comm.DownloadService
com.mfcloudcalculate.networkdisk/com.qq.e.ads.ADActivity
com.mfcloudcalculate.networkdisk/com.qq.e.ads.PortraitADActivity
com.mfcloudcalculate.networkdisk/com.qq.e.ads.LandscapeADActivity
com.mfcloudcalculate.networkdisk/com.qq.e.ads.RewardvideoPortraitADActivity
com.mfcloudcalculate.networkdisk/com.qq.e.ads.RewardvideoLandscapeADActivity
com.mfcloudcalculate.networkdisk/com.qq.e.ads.DialogActivity
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Portrait_Activity
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity_T
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Landscape_Activity
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_Activity
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity_T
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity
com.mfcloudcalculate.networkdisk/com.bytedance.sdk.openadsdk.stub.server.DownloaderServerManager
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.AdWebViewActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.KsFullScreenVideoActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.KsFullScreenLandScapeVideoActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.KsRewardVideoActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.KSRewardLandScapeVideoActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.FeedDownloadActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$KsTrendsActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ProfileHomeActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ProfileVideoDetailActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$TubeProfileActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ChannelDetailActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$TubeDetailActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$EpisodeDetailActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity1
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$GoodsPlayBackActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity2
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity3
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity4
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity5
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity6
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity7
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity8
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity9
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity10
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleTop1
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleTop2
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleInstance1
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleInstance2
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$DeveloperConfigActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivity
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivitySingleTop1
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivitySingleTop2
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivitySingleTask1
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivitySingleTask2
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivitySingleInstance1
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.BaseFragmentActivity$LandscapeFragmentActivitySingleInstance2
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.FileDownloadService$SharedMainProcessService
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.FileDownloadService$SeparateProcessService
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.DownloadService
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.ServiceProxyRemote
com.mfcloudcalculate.networkdisk/com.kwad.sdk.api.proxy.app.AdSdkFileProvider
com.mfcloudcalculate.networkdisk/com.alipay.mobile.logmonitor.ClientMonitorExtReceiver
'

for i in ${disable_list}
do
	pm disable "${i}" >/dev/null 2>&1
done


id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

find /sdcard/Android/data/com.mfcloudcalculate.networkdisk /data/user/0/com.mfcloudcalculate.networkdisk -iname '*logcat*' -type d -o -iname 'BeiZi' -type d -o -iname 'applog' -type d -o -iname 'AMPS' -type d -o -iname 'crashsdk' -type d -o -iname 'app_baidu_sdk_remote' -type d -o -iname 'app_adnet' -type d -o -iname 'app_e_qq_com_*' -type d -o -iname 'ks_union' -type d -o -iname 'ksad_dynamic' -type d -o -iname 'kwad_ex' -type d 2>/dev/null | while read Folder ;do
	test -d "${Folder}" && mkdir_file "${Folder}"
done


find /sdcard/Android/data/com.mfcloudcalculate.networkdisk /data/user/0/com.mfcloudcalculate.networkdisk -iname '*crash*' -type f -o -iname "*.log" -type f -o -iname "*.xlog" -type f -o -iname "*.logs" -type f 2>/dev/null | while read File ;do
	test -f "${File}" && mkdir_file "${File}"
done




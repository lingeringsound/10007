iptables -A OUTPUT -m string --string "googleadservices.com" --algo bm --to 65535 -j DROP
iptables -A OUTPUT -m string --string "www.googleadservices.com" --algo bm --to 65535 -j DROP

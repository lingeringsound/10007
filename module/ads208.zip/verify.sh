function Check_files(){
local Check_file="${MODPATH}/其他脚本/废弃脚本/file_list.sha256"
echo -e "\n※ 检验文件中……\n"
for i in `cat "${Check_file}" | sed '/^#/d;/^[[:space:]]*$/d'`
do
file_path="${MODPATH}/$(echo "${i}" | cut -d'|' -f1 | sed 's|\/\/|\/|g')"
file_sha256="$(echo "${i}" | cut -d'|' -f2)"
test ! -f "${file_path}" && echo -e "※[?] ${file_path##*/}文件缺失" && continue
if ! (echo "${file_sha256}" "$file_path" | sha256sum -c -s -) ;then
	echo -e "※ ${file_path##*/} 文件被修改\n※ 确保从官方渠道下载！"
	abort "…………"
fi
	done
echo "※[✔] 完成！"
}

Check_files



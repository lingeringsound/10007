id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

source $MODPATH/mod/util_functions.sh

Running_bin="${MODPATH}/mod/ads_monitor/ads_monitor"
Running_config="${MODPATH}/mod/ads_monitor/ads_monitor.prop"
config_apps="$(cat "${Running_config}" | sed "/#/d;/^[[:space:]]*$/d;s|/data/user/0/||g;s|/data/media/0/Android/data/||g;s|/.*||g" | sort -u)"

function fixed_owner(){
local package_name="${1}"
test "${package_name}" != ""
local uid="$(cmd package list package -U "${package_name}" 2>/dev/null | grep "package:${package_name}[[:space:]]uid:" | sed 's/.*uid://g' | tr -cd [0-9])"
[ "${uid}" = "" ] && uid=`dumpsys package "${package_name}"  2>/dev/null | grep -Eo 'userId=[0-9]{4,6}|uid=[0-9]{4,6}' | sed 's/.*=//g' | sort -u`
[ "${uid}" = "" ] && uid=`cat /data/system/packages.list 2>/dev/null | grep -Eo "${package_name}[[:space:]]+[0-9]{4,6}" | sed -E 's/(.*)[[:space:]]([0-9]{4,6})/\2/g'`
if test "${uid}" != "" -a -d "/data/media/0/Android/data/${package_name}" ;then
chmod -R 2770 "/data/media/0/Android/data/${package_name}"
chown -R "${uid}:${uid}" "/data/media/0/Android/data/${package_name}"
chmod -R 2775 "/data/user/0/${package_name}"
chown -R "${uid}:${uid}" "/data/user/0/${package_name}"
chattr -i -a -R "/data/media/0/Android/data/${package_name}"
chattr -i -a -R "/data/user/0/${package_name}"
fi
}

if ! dumpsys -l | grep 'cpuinfo' >/dev/null 2>&1 ;then
	Log_10007_dmesg "@10007 dumpsys service cpuinfo does not exist" "E"
else
a="1"
until $(dumpsys cpuinfo | grep 'ads_monitor' >/dev/null 2>&1)
do
	test "${a}" = "3" && break
	a="$(($a + 1))"
	sleep 5m
done
for app in $config_apps
do
	fixed_owner "$app"
done
sleep 30s
for app in $config_apps
do
	fixed_owner "$app"
done
fi

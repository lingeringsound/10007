id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
local_MODPATH="/data/adb/$Magisk_mod/$id"

function set_perm() {
  chown -R $2:$3 "${1}" >/dev/null 2>&1
  chmod -R $4 "${1}" >/dev/null 2>&1
  local CON=$5
  [ -z $CON ] && CON=u:object_r:system_file:s0
  chcon -R $CON "${1}" >/dev/null 2>&1
}

function mount_set_perm_for_hosts(){
local target_file="${1}"
test ! -f "${target_file}" && return
local system_host="/system/etc/hosts"
if test ! -f "${system_host}" ;then
for file in $(find /system/ /system_ext /vendor /product -iname 'hosts' -type f 2>/dev/null)
do
case "${file}" in
/system_ext* | /vendor* | /product*)
	system_host="/system"${file}""
	break
;;
/system*)
	system_host="${file}"
	break
;;
		esac
	done
fi
local perm_hosts="$(`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1` stat -c '%U %G %a' ${system_host} 2>/dev/null )"
local selinux_context="$(`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1` stat -Z ${system_host} 2>/dev/null | grep -i 'S_Context:' | sed 's/.*u:/u:/g' )"
test "${selinux_context}" = "" && selinux_context="u:object_r:system_file:s0"
set_perm "${target_file%/*}" ${perm_hosts} "${selinux_context}"
umount "${system_host}" >/dev/null 2>&1
mount --bind "${target_file}" "${system_host}" >/dev/null 2>&1
}

echo -e "\n- ※免重启挂载hosts文件……"
cp -rf "${MODPATH}/Host"/* "${local_MODPATH}/Host" && echo -e "- ※复制文件中……"

if test "$(show_value '广告奖励')" = "否" ;then
	mount_set_perm_for_hosts "${local_MODPATH}/Host/all" && echo "- ※挂载 all 文件" || echo -e "- <<< 失败 >>>"
else
	mount_set_perm_for_hosts "${local_MODPATH}/Host/reward" && echo "- ※挂载 reward 文件" || echo -e "- <<< 失败 >>>"
fi
echo "- ※完成！"
echo "∞————————————————————————∞"
echo ""

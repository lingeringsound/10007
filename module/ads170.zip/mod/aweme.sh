id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

find /data/user/*/com.ss.android.ugc.aweme /data/data/com.ss.android.ugc.aweme /data/media/*/Android/data/com.ss.android.ugc.aweme -iname "offlineX" -type d -o -iname "ALOG" -type d -o -iname "apm6_sdk" -type d -o -iname "apm6" -type d -o -iname "logs" -type d -o -iname "log" -type d 2>/dev/null | while read adfile
do
	mkdir_file $adfile 2>/dev/null 
done

#修复抖音插件文件夹空文件占用
find /data/user/*/com.ss.android.ugc.aweme /data/data/com.ss.android.ugc.aweme /data/media/*/Android/data/com.ss.android.ugc.aweme -iname "plugins" -type f | while read file
do
	rm -rf "$file"
done


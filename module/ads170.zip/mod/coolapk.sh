#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh



find /data/user/*/com.coolapk.market /data/data/com.coolapk.market /data/media/*/Android/data/com.coolapk.market -iname "tt_mediation_open_sdk.db" -type f -o -iname "GDTDOWNLOAD" -type d -o -iname "tad_cache" -type d -o -iname "app_ad" -type d -o -iname "TTCache" -type d -o -iname "app_ad" -type d -o -iname "cachett_ad" -type d -o -iname "splash_image" -type d -o -iname "tt_tmpl_pkg" -type d -o -iname "com_qq_e_download" -type d -o -iname "pangle_com.byted.pangle" -type d -o -perm 000 2>/dev/null | while read adfile ;do
	mkdir_file $adfile 2>/dev/null 
done


function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
AUDIO_MEDIA_VOLUME
CHANGE_WIFI_STATE
FINE_LOCATION
LEGACY_STORAGE
MOCK_LOCATION
MONITOR_HIGH_POWER_LOCATION
MONITOR_LOCATION
READ_CALENDAR
READ_DEVICE_IDENTIFIERS
READ_PHONE_STATE
READ_EXTERNAL_STORAGE
SYSTEM_ALERT_WINDOW
TAKE_AUDIO_FOCUS
VIBRATE
WAKE_LOCK
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
"
for ops in $list 
do
	cmd appops set $package $ops $action
done
}

deny_appops "com.coolapk.market" "ignore" >/dev/null 2>&1
cmd appops set 'com.coolapk.market' 'allow' 'TOAST_WINDOW' >/dev/null 2>&1

for file in /data/user/*/com.coolapk.market/databases/pangle_com.byted.pangle.*.db
	do
	if test -f "${file}" ;then
		rm -rf "${file}"
			mkdir -p "${file%/*}"
				touch "${file}"
			chmod 0000 "${file}"
		chown "root:root" "${file}"
	fi
done
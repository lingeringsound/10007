#!/system/bin/sh

function add_value() {
local file="${1}"
local local_host_file="${2}"
local name="$(echo ${file##*/}| sed "s|\..*||g")"
local add_value="$(cat "${file}" | sed "s/0.0.0.0//g;s/^[[:space:]]//g;s/127.0.0.1//g;s/^[[:space:]]//g;/^#.*/d;/^[[:space:]]*$/d")"
if test -f "${file}" ;then
	echo "$add_value" | while read host ;do
cat <<key>>$local_host_file
#${name}
127.0.0.1 $host
#END
key
	done
fi
}

function wipe_value() {
local file="${1}"
local local_host_file="${2}"
if test -f "$file" ; then
for i in $(cat "${file}" | sed "s/0.0.0.0//g;s/^[[:space:]]//g;s/127.0.0.1//g;s/^[[:space:]]//g;/^#.*/d;/^[[:space:]]*$/d" )
	do
	sed -i "/$i/d" $local_host_file
done
fi
}

function mod_host_file() {
local file="${2}"
local value="${1}"
local dir="${0%/*}"
find "${dir}" -iname "hosts" -type f | while read target_host ;do
if test "${value}" = "添加" ;then
add_value "$file" "${target_host}"
elif test "${value}" = "删除" ;then
wipe_value "$file" "${target_host}"
fi
done
}

#添加host
#mod_host_file "添加" "文件名"
#例如
mod_host_file "添加" "${0%/*}/自定义.conf"

#删除host
#mod_host_file "删除" "文件名"
#例如
#mod_host_file "删除" "${0%/*}/自定义.conf"


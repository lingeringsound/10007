#!/sbin/sh

#恢复host拦截
find /data/adb/modules -type f -iname "hosts.bak" | while read file ;do
mv -f "${file}" "${file%/*}/hosts"
done

#恢复虎牙屏蔽
iptables -F

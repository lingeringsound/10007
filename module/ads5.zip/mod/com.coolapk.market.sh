#!/system/bin

#disable 代表禁用
#enable 代表启用
sate=disable 

disable_list='
com.coolapk.market/com.qq.e.ads.DialogActivity
com.coolapk.market/com.qq.e.ads.ADActivity
com.coolapk.market/com.qq.e.ads.LandscapeADActivity
com.coolapk.market/com.qq.e.ads.PortraitADActivity
com.coolapk.market/com.qq.e.ads.RewardvideoLandscapeADActivity
com.coolapk.market/com.qq.e.ads.RewardvideoPortraitADActivity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity_T
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity_T
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Landscape_Activity
com.coolapk.market/com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Portrait_Activity
com.coolapk.market/com.ss.android.downloadlib.activity.TTDelegateActivity
com.coolapk.market/com.bytedance.sdk.open.douyin.ui.DouYinWebAuthorizeActivity
com.coolapk.market/com.qq.e.comm.DownloadService
'

for i in $disable_list 
do
pm $sate $i
done
#!/system/bin/sh

local_host_file=$MODPATH/hosts

function correctpath() {
	case $(echo "$1") in
	/system_ext* | /vendor* | /product*)
		echo "/system"$1""
		;;
	/system*)
		echo "$1"
		;;
	esac
}

function mk_new_file() {
	local file=$1
	local new=$(cat "${file}" | sort | uniq)
	echo "$new" >"${file}"
}

function grep_host() {
	find /data/adb/modules -type f -iname "hosts" | cut -d'/' -f5 | sort | uniq | grep -v "$id"
}

for o in $(grep_host); do
	for i in $(ls /data/adb/modules); do
		name=$(cat /data/adb/modules/$i/module.prop | grep 'name' | cut -d = -f2)
		author=$(cat /data/adb/modules/$i/module.prop | grep 'author' | cut -d = -f2)
		description=$(cat /data/adb/modules/$i/module.prop | grep 'description' | cut -d = -f2)
		size=$(du -sh /data/adb/modules/$i | sed "s|/data/adb/modules/$i||g")
		if test "$i" = "$o" -a "$i" != "$id"; then
			echo " "
			echo "∞————————————————————————∞"
			echo ""
			echo "－名称：$name"
			echo "－作者：$author"
			echo "－简介：$description"
			echo " "
			echo "－大小：$size"
			echo " "
			echo "－ 该模块含有hosts！"
			echo ""
			echo "－ 正在合并模块中……"
			echo ""
			find "/data/adb/modules/$i" -iname "hosts" -type f | while read mod_hostfile; do
				echo "$(cat "${mod_hostfile}")" >> $local_host_file && {
				mv -f "${mod_hostfile}" "${mod_hostfile}.bak"
				}
			done
			echo "∞————————————————————————∞"
			echo " "
		fi
	done
done

find /system/ /system_ext /vendor /product -iname 'hosts' -type f 2>/dev/null | while read hostfile; do
	mkdir -p "$MODPATH${hostfile%/*}"
	cp -rf $local_host_file "$MODPATH${hostfile}"
	mk_new_file "$MODPATH${hostfile}"
done && rm -rf $local_host_file

busyboxdir=$MODPATH/busybox
magiskbusybox=/data/adb/magisk/busybox
kernelbusybox=`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1`
if test -f "${magiskbusybox}" ;then
chmod 0777 "${magiskbusybox}"
	mkdir -p "${busyboxdir}"
	echo "－ 安装Magisk的busybox 中……"
${magiskbusybox} --install -s ${busyboxdir} && echo "－ 完成！" || abort "－ 错误！"
elif test -f "${kernelbusybox}" ;then
chmod 0777 "${kernelbusybox}"
	mkdir -p "${busyboxdir}"
	echo "－ 安装Magisk的busybox 中……"
${kernelbusybox} --install -s ${busyboxdir} && echo "－ 完成！" || abort "－ 错误！"
else
	abort "－ 您的magisk busybox 怎么不见了？"
fi
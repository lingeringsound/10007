#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/inotify.h>
#include <pthread.h>
#include <errno.h>
#include <dirent.h>
#include <stdio.h>

#define PATH_MAX 4096
#define RETRY_DELAY_US 100000
#define MAX_RETRIES 5

// 跳过路径列表
static const char *skipPaths[] = {
    "/acct", "/odm_dlkm", "/apex", "/oem", "/bin", "/opconfig", "/cache", "/opcust", "/config", "/postinstall",
    "/cust", "/proc", "/d/", "/product", "/data_mirror", "/second_stage_resources", "/debug_ramdisk", "/dev", "/sys",
    "/etc", "/system", "/linkerconfig", "/system_ext", "/lost+found", "/tmp", "/metadata", "/vendor", "/mnt", "/vendor_dlkm", "/odm"
};
static const int skipPathsCount = sizeof(skipPaths) / sizeof(skipPaths[0]);

static const char *skipFullPaths[] = {
    "/data/user/", "/data/user", "/data/media/0/Android/data/", "/data/media/0/Android/data", "/data/data/", "/data/data",
    "/data", "/data/", "/data/media/0", "/data/media/0/", "/data/media/0/Downloa", "/data/media/0/Download/", "/data/media/0/Android",
    "/data/media/0/Android/", "/sdcard", "/sdcard/", "/sdcard/Download", "/sdcard/Download/", "/sdcard/Android", "/sdcard/Android/",
    "/storage", "/storage/", "/storage/emulated/0", "/storage/emulated/0/", "/storage/emulated/0/Download", "/storage/emulated/0/Download/",
    "/storage/emulated/0/Android", "/storage/emulated/0/Android/", "/"
};
static const int skipFullPathsCount = sizeof(skipFullPaths) / sizeof(skipFullPaths[0]);

// 动态数组结构体
typedef struct {
    char **data;
    size_t size;
    size_t capacity;
} StringArray;

// 日志宏
#define LOG_INFO(fmt, ...) do { printf(fmt "\n", ##__VA_ARGS__); fflush(stdout); } while (0)
#define LOG_ERROR(fmt, ...) do { fprintf(stderr, fmt " (%s)\n", ##__VA_ARGS__, strerror(errno)); fflush(stderr); } while (0)

// 函数声明
static void initStringArray(StringArray *arr);
static void appendStringArray(StringArray *arr, const char *str);
static void freeStringArray(StringArray *arr);
static int shouldSkipPath(const char *path);
static StringArray readConfigFile(const char *configFile);
static char *getUserDataDir(void);
static char *getMediaDataDir(void);
static char *getParentDir(const char *path);
static char *getAppDir(const char *path);
static int createDirRecursively(const char *path, uid_t uid, gid_t gid);
static int createFile(const char *filename, uid_t *uid, gid_t *gid);
static int removePathRecursive(const char *path);
static void *monitorFile(void *arg);

// 动态数组实现
static void initStringArray(StringArray *arr) {
    arr->size = 0;
    arr->capacity = 4;
    arr->data = malloc(arr->capacity * sizeof(char *));
}

static void appendStringArray(StringArray *arr, const char *str) {
    if (arr->size >= arr->capacity) {
        arr->capacity *= 2;
        arr->data = realloc(arr->data, arr->capacity * sizeof(char *));
    }
    arr->data[arr->size++] = strdup(str);
}

static void freeStringArray(StringArray *arr) {
    for (size_t i = 0; i < arr->size; i++) free(arr->data[i]);
    free(arr->data);
    arr->size = arr->capacity = 0;
}

// 是否跳过路径
static int shouldSkipPath(const char *path) {
    for (int i = 0; i < skipPathsCount; i++) {
        if (strncmp(path, skipPaths[i], strlen(skipPaths[i])) == 0) return 1;
    }
    for (int i = 0; i < skipFullPathsCount; i++) {
        if (strcmp(path, skipFullPaths[i]) == 0) return 1;
    }
    return 0;
}

// 读取配置文件
static StringArray readConfigFile(const char *configFile) {
    StringArray filePaths;
    initStringArray(&filePaths);

    FILE *file = fopen(configFile, "r");
    if (!file) {
        LOG_ERROR("无法打开配置文件: %s", configFile);
        return filePaths;
    }

    char line[PATH_MAX];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0;
        if (strlen(line) == 0 || line[0] == '#') continue;
        appendStringArray(&filePaths, line);
    }
    fclose(file);
    LOG_INFO("配置文件读取完成，路径数: %zu", filePaths.size);
    return filePaths;
}

// 获取用户数据目录
static char *getUserDataDir(void) {
    char *androidData = getenv("ANDROID_DATA");
    if (androidData) {
        char *userDir = malloc(strlen(androidData) + 8);
        snprintf(userDir, PATH_MAX, "%s/user/0", androidData);
        if (access(userDir, F_OK) == 0) return userDir;
        free(userDir);
    }
    char *defaultDir = strdup("/data/user/0");
    if (access(defaultDir, F_OK) == 0) return defaultDir;
    free(defaultDir);
    return strdup("/data/user");
}

// 获取媒体数据目录
static char *getMediaDataDir(void) {
    char *androidData = getenv("ANDROID_DATA");
    if (androidData) {
        char *mediaDir = malloc(strlen(androidData) + 9);
        snprintf(mediaDir, PATH_MAX, "%s/media/0", androidData);
        if (access(mediaDir, F_OK) == 0) return mediaDir;
        free(mediaDir);
    }
    char *defaultDir = strdup("/data/media/0");
    if (access(defaultDir, F_OK) == 0) return defaultDir;
    free(defaultDir);
    return strdup("/data/media");
}

// 获取父目录
static char *getParentDir(const char *path) {
    char *copy = strdup(path);
    char *lastSlash = strrchr(copy, '/');
    if (lastSlash && lastSlash != copy) {
        *lastSlash = '\0';
    } else {
        free(copy);
        return strdup("/");
    }
    return copy;
}

// 获取应用目录
static char *getAppDir(const char *path) {
    char *copy = strdup(path);
    char *userDataDir = getUserDataDir();
    char *mediaDataDir = getMediaDataDir();
    char *pos;

    if ((pos = strstr(copy, userDataDir)) == copy) {
        pos += strlen(userDataDir) + 1;
        char *nextSlash = strchr(pos, '/');
        if (nextSlash) {
            *nextSlash = '\0';
            char *appDir = malloc(strlen(userDataDir) + strlen(pos) + 2);
            snprintf(appDir, PATH_MAX, "%s/%s", userDataDir, pos);
            free(copy);
            free(userDataDir);
            free(mediaDataDir);
            return appDir;
        }
    } else if ((pos = strstr(copy, mediaDataDir)) == copy) {
        pos += strlen(mediaDataDir) + strlen("/Android/data/");
        char *nextSlash = strchr(pos, '/');
        if (nextSlash) {
            *nextSlash = '\0';
            char *appDir = malloc(strlen(mediaDataDir) + strlen("/Android/data/") + strlen(pos) + 2);
            snprintf(appDir, PATH_MAX, "%s/Android/data/%s", mediaDataDir, pos);
            free(copy);
            free(userDataDir);
            free(mediaDataDir);
            return appDir;
        }
    }

    free(copy);
    free(mediaDataDir);
    char *fallback = malloc(strlen(userDataDir) + 2);
    snprintf(fallback, PATH_MAX, "%s", userDataDir);
    free(userDataDir);
    return fallback;
}

// 递归创建目录
static int createDirRecursively(const char *path, uid_t uid, gid_t gid) {
    char temp[PATH_MAX];
    snprintf(temp, sizeof(temp), "%s", path);

    char *pos;
    for (pos = temp + 1; *pos; pos++) {
        if (*pos == '/') {
            *pos = '\0';
            struct stat st;
            if (stat(temp, &st) != 0) {
                if (mkdir(temp, 0755) && errno != EEXIST) {
                    LOG_ERROR("无法创建文件夹: %s", temp);
                    return -1;
                }
                if (lchown(temp, uid, gid) != 0) {
                    LOG_ERROR("无法设置目录所有者: %s", temp);
                }
            }
            *pos = '/';
        }
    }
    struct stat st;
    if (stat(temp, &st) != 0) {
        if (mkdir(temp, 0755) && errno != EEXIST) {
            LOG_ERROR("无法创建文件夹: %s", temp);
            return -1;
        }
        if (lchown(temp, uid, gid) != 0) {
            LOG_ERROR("无法设置目录所有者: %s", temp);
        }
    }
    return 0;
}

// 创建文件
static int createFile(const char *filename, uid_t *uid, gid_t *gid) {
    LOG_INFO("尝试创建文件: %s", filename);

    char *parentDir = getParentDir(filename);
    char *appDir = getAppDir(filename);

    struct stat app_st;
    if (stat(appDir, &app_st) != 0) {
        LOG_ERROR("无法获取应用目录信息: %s，使用默认值", appDir);
        *uid = 1000;
        *gid = 1000;
    } else {
        *uid = app_st.st_uid;
        *gid = app_st.st_gid;
    }
    LOG_INFO("从应用目录读取的所有者: UID=%d, GID=%d: %s", *uid, *gid, appDir);

    if (createDirRecursively(parentDir, *uid, *gid) != 0) {
        LOG_ERROR("无法创建父目录: %s", parentDir);
        free(parentDir);
        free(appDir);
        return -1;
    }

    struct stat st;
    if (stat(filename, &st) == 0) {
        if (S_ISDIR(st.st_mode)) {
            LOG_INFO("目标路径是文件夹，删除: %s", filename);
            if (removePathRecursive(filename) != 0) {
                LOG_ERROR("无法删除目标文件夹: %s", filename);
                free(parentDir);
                free(appDir);
                return -1;
            }
        } else {
            LOG_INFO("目标路径是文件，删除: %s", filename);
            if (unlink(filename) != 0) {
                LOG_ERROR("无法删除目标文件: %s", filename);
                free(parentDir);
                free(appDir);
                return -1;
            }
        }
    }

    FILE *file = NULL;
    for (int attempts = 0; attempts < MAX_RETRIES && !file; attempts++) {
        file = fopen(filename, "w");
        if (!file) {
            if (errno == EISDIR) {
                LOG_INFO("目标路径变为文件夹，删除: %s", filename);
                if (removePathRecursive(filename) != 0) {
                    LOG_ERROR("无法删除目标文件夹: %s", filename);
                    break;
                }
            }
            if (attempts < MAX_RETRIES - 1) usleep(RETRY_DELAY_US);
        }
    }
    if (!file) {
        LOG_ERROR("多次尝试后仍无法创建文件: %s", filename);
        free(parentDir);
        free(appDir);
        return -1;
    }

    fclose(file);
    LOG_INFO("文件已创建: %s", filename);

    if (lchown(filename, *uid, *gid) != 0) {
        LOG_ERROR("无法设置文件所有者: %s", filename);
    } else {
        LOG_INFO("文件所有者设置为: UID=%d, GID=%d: %s", *uid, *gid, filename);
    }

    if (chmod(filename, 0600) != 0) {
        LOG_ERROR("无法设置文件权限为0600: %s", filename);
    } else {
        LOG_INFO("文件权限已设置为0600: %s", filename);
    }

    free(parentDir);
    free(appDir);
    return 0;
}

// 递归删除路径
static int removePathRecursive(const char *path) {
    struct stat st;
    if (lstat(path, &st) == -1) {
        if (errno == ENOENT) return 0;
        LOG_ERROR("无法访问路径: %s", path);
        return -1;
    }

    if (S_ISDIR(st.st_mode)) {
        DIR *dir = opendir(path);
        if (!dir) {
            LOG_ERROR("无法打开目录: %s", path);
            return -1;
        }

        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
            char subPath[PATH_MAX];
            snprintf(subPath, sizeof(subPath), "%s/%s", path, entry->d_name);
            if (removePathRecursive(subPath) != 0) {
                closedir(dir);
                return -1;
            }
        }
        closedir(dir);
        if (rmdir(path) != 0) {
            LOG_ERROR("无法删除目录: %s", path);
            return -1;
        }
    } else {
        if (unlink(path) != 0) {
            LOG_ERROR("无法删除文件: %s", path);
            return -1;
        }
    }

    LOG_INFO("路径已删除: %s", path);
    return 0;
}

// 文件监控线程（阻塞模式）
static void *monitorFile(void *arg) {
    char *filename = (char *)arg;
    LOG_INFO("开始监控文件: %s", filename);

    char *appDir = getAppDir(filename);
    uid_t orig_uid = 1000, orig_gid = 1000;
    struct stat app_st;
    if (stat(appDir, &app_st) == 0) {
        orig_uid = app_st.st_uid;
        orig_gid = app_st.st_gid;
    } else {
        LOG_ERROR("无法获取应用目录信息，默认使用 system 用户: %s", appDir);
    }
    free(appDir);

    int inotifyFd = inotify_init(); // 恢复阻塞模式
    if (inotifyFd == -1) {
        LOG_ERROR("无法初始化 inotify: %s", filename);
        free(filename);
        return NULL;
    }

    int wd = inotify_add_watch(inotifyFd, filename, IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE | IN_CREATE);
    if (wd == -1) {
        LOG_ERROR("无法添加 inotify 监控: %s", filename);
        close(inotifyFd);
        free(filename);
        return NULL;
    }

    char buf[4096] __attribute__((aligned(__alignof__(struct inotify_event))));
    ssize_t numRead;

    while (1) {
        numRead = read(inotifyFd, buf, sizeof(buf)); // 阻塞等待事件
        if (numRead <= 0) {
            LOG_ERROR("inotify 读取失败或关闭: %s", filename);
            break;
        }

        for (char *ptr = buf; ptr < buf + numRead;) {
            struct inotify_event *event = (struct inotify_event *)ptr;
            LOG_INFO("检测到文件事件: %s (mask: %u)", filename, event->mask);

            if (event->mask & (IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE | IN_CREATE)) {
                char *parentDir = getParentDir(filename);
                struct stat st;
                if (stat(filename, &st) != 0 || S_ISDIR(st.st_mode)) {
                    LOG_INFO("文件不存在或变为文件夹，开始重建: %s", filename);
                    removePathRecursive(filename);
                    if (createDirRecursively(parentDir, orig_uid, orig_gid) == 0) {
                        if (createFile(filename, &orig_uid, &orig_gid) != 0) {
                            LOG_ERROR("文件重建失败: %s", filename);
                        }
                    }
                }
                free(parentDir);

                inotify_rm_watch(inotifyFd, wd);
                wd = inotify_add_watch(inotifyFd, filename, IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE | IN_CREATE);
                if (wd == -1) {
                    LOG_ERROR("无法重新添加 inotify 监控: %s", filename);
                    usleep(RETRY_DELAY_US);
                    if (createFile(filename, &orig_uid, &orig_gid) == 0) {
                        wd = inotify_add_watch(inotifyFd, filename, IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_DELETE | IN_CREATE);
                        if (wd != -1) {
                            LOG_INFO("成功重新添加监控: %s", filename);
                        }
                    }
                } else {
                    LOG_INFO("成功重新添加监控: %s", filename);
                }
            }
            ptr += sizeof(struct inotify_event) + event->len;
        }
    }

    close(inotifyFd);
    free(filename);
    LOG_INFO("监控线程结束: %s", filename);
    return NULL;
}

// 主函数
int main(int argc, char *argv[]) {
    char *configFile = NULL;
    int opt;

    while ((opt = getopt(argc, argv, "f:")) != -1) {
        switch (opt) {
            case 'f': configFile = optarg; break;
            default:
                LOG_ERROR("用法: %s -f <配置文件路径>", argv[0]);
                return 1;
        }
    }

    if (!configFile) {
        LOG_ERROR("配置文件路径不能为空");
        return 1;
    }

    StringArray filePaths = readConfigFile(configFile);
    if (filePaths.size == 0) {
        LOG_ERROR("无法读取配置文件或文件为空: %s", configFile);
        return 1;
    }

    // 初始化路径
    for (size_t i = 0; i < filePaths.size; i++) {
        const char *filePath = filePaths.data[i];
        LOG_INFO("初始化路径: %s", filePath);

        if (shouldSkipPath(filePath)) {
            LOG_INFO("跳过路径: %s", filePath);
            continue;
        }

        char *appDir = getAppDir(filePath);
        uid_t uid = 1000, gid = 1000;
        struct stat app_st;
        if (stat(appDir, &app_st) == 0) {
            uid = app_st.st_uid;
            gid = app_st.st_gid;
        }
        free(appDir);

        char *parentDir = getParentDir(filePath);
        removePathRecursive(filePath);
        createDirRecursively(parentDir, uid, gid);
        createFile(filePath, &uid, &gid);
        free(parentDir);
    }

    // 计算有效路径数
    size_t validPathCount = 0;
    for (size_t i = 0; i < filePaths.size; i++) {
        if (!shouldSkipPath(filePaths.data[i])) validPathCount++;
    }

    // 动态分配线程数组
    pthread_t *threads = malloc(validPathCount * sizeof(pthread_t));
    size_t threadCount = 0;

    for (size_t i = 0; i < filePaths.size; i++) {
        const char *filePath = filePaths.data[i];
        if (shouldSkipPath(filePath)) continue;

        char *filePathCopy = strdup(filePath);
        if (pthread_create(&threads[threadCount], NULL, monitorFile, filePathCopy) != 0) {
            LOG_ERROR("无法创建线程: %s", filePath);
            free(filePathCopy);
        } else {
            threadCount++;
            LOG_INFO("线程创建成功，路径: %s，总线程数: %zu", filePath, threadCount);
        }
    }

    for (size_t i = 0; i < threadCount; i++) {
        pthread_join(threads[i], NULL);
        LOG_INFO("线程 %zu 已结束", i);
    }

    free(threads);
    freeStringArray(&filePaths);
    LOG_INFO("程序执行完成");
    return 0;
}
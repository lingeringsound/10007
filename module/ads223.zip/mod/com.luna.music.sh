id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

#番茄阅读插件
#-o -iname "plugins" -type d 

find /data/user/*/com.luna.music /data/data/com.luna.music /data/media/*/Android/data/com.luna.music  -iname ".geckox" -type d -o -iname "offlineX" -type d -o -iname "ALOG" -type d -o -iname "apm6*" -type d -o -iname "luckycat_gecko_root_dir" -type d -o -iname "webview_bytedance" -type d -o -iname "splash_*" -type d 2>/dev/null | while read adfile
do
	mkdir_file $adfile 2>/dev/null 
done


function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
#振动权限
VIBRATE
#写入日历
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
#身体传感器
ACTIVITY_RECOGNITION
BODY_SENSORS
#系统浮窗
SYSTEM_ALERT_WINDOW
#音量控制
TAKE_AUDIO_FOCUS
AUDIO_MEDIA_VOLUME
#手机信息
READ_PHONE_STATE
"
for ops in $list 
do
	echo "${ops}" | grep -q "^#" && continue
	cmd appops set $package $ops $action
done
}

deny_appops "com.luna.music" "ignore"

function fixed_owner(){
local package_name="${1}"
test "${package_name}" != ""
local uid="$(cmd package list package -U "${package_name}" 2>/dev/null | grep "package:${package_name}[[:space:]]uid:" | sed 's/.*uid://g' | tr -cd [0-9])"
[ "${uid}" = "" ] && uid=`dumpsys package "${package_name}"  2>/dev/null | grep -Eo 'userId=[0-9]{4,6}|uid=[0-9]{4,6}' | sed 's/.*=//g' | sort -u`
[ "${uid}" = "" ] && uid=`cat /data/system/packages.list 2>/dev/null | grep -Eo "${package_name}[[:space:]]+[0-9]{4,6}" | sed -E 's/(.*)[[:space:]]([0-9]{4,6})/\2/g'`
if test "${uid}" != "" -a -d "/data/media/0/Android/data/${package_name}" ;then
	chmod -R 2770 "/data/media/0/Android/data/${package_name}"
		chown -R "${uid}:${uid}" "/data/media/0/Android/data/${package_name}"
			chmod -R 2775 "/data/user/0/${package_name}"
			chown -R "${uid}:${uid}" "/data/user/0/${package_name}"
		chattr -i -a -R "/data/media/0/Android/data/${package_name}"
	chattr -i -a -R "/data/user/0/${package_name}"
fi
}

fixed_owner "com.tencent.mobileqq"

placeholder_files="
/data/media/[0-9]*/[Tt]encent/TMAssistantSDK
/data/media/[0-9]*/Android/data/com.tencent.mobileqq/[Tt]encent/TMAssistantSDK
"

for i in `ls ${placeholder_files} 2>/dev/null `
do
	test -f "${i}" && rm -rf "${i}"
done

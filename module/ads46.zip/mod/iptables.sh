list="
#谷歌和doubleclick广告
ad-emea.doubleclick.net
static.doubleclick.net
www.googleadservices.com
googleadservices.com
ad.doubleclick.net
doubleclick.net
302br.net
#禁漫
poweredby.jads.co
ck.jads.co
#admaster
admaster.com.cn
admaster.com
admaster.cn
#其他
sprout-ad.com
chat.api.drift.com
live.api.drift.com
log.optimizely.com
analytics.mobilegamestats.com
ads.pointroll.com
ads.tremorhub.com
ad.corp.appnexus.com
api-05.com
log.xoalt.com
c.admaster.com.cn
api.pushwoosh.com
api.5rocks.io
api.botman.ninja
api.splkmobile.com

"
local IFS=$'\n'
for i in $list ;do
#排除注释
test "$(echo $i | grep -w '^#')" != "" && continue
#禁用网址和子域名
iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
#iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done 


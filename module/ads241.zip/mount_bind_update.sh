Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
local_MODPATH="/data/adb/$Magisk_mod/$id"
old_mount_bind_file="${local_MODPATH}/mod/mount_hosts/配置包名.prop"
new_mount_bind_file="$MODPATH/mod/mount_hosts/配置包名.prop"

test ! -e $old_mount_bind_file && return 0

package_old_content="$(cat "${old_mount_bind_file}" | sed '/^#/d;/=/d;/^[[:space:]]*$/d' | sort -u)"
package_update_content="$(cat "${new_mount_bind_file}" | sed '/^#/d;/=/d;/^[[:space:]]*$/d' | sort -u)"

function show_value() {
	local value=$1
	local file="${2}"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function replace_value() {
	local name="${1}"
	local value="$(show_value "${name}" "${old_mount_bind_file}" )"
	local file="${2}"
	if test "$value" != "" ;then
		sed -i "s|^$name=.*|$name=$value|g" "$file"
#		echo " 修改 [ $name ] 值为 [ $value ]"
#	else 
#		echo "添加新的配置选项 [ $name ] 值为 [ $(show_value "${name}" "$conf_file") ]"
	fi
}


if [[ "$(echo "${package_update_content}" | wc -l)" != "$(echo "${package_old_content}" | wc -l)" ]]; then
sed -E -i '/\#选择放行广告奖励的包名/,/^[[:space:]]$/d' "${new_mount_bind_file}"
cat << key >> "${new_mount_bind_file}"
#选择放行广告奖励的包名
#玩游戏请把上面的reward改成recovery更好，hosts为默认。
${package_old_content}

key
fi

for i in $(cat "$new_mount_bind_file" | sed '/^#/d;/^[[:space:]]*$/d;s/=.*//g' )
do
	replace_value "$i" "$new_mount_bind_file"
done


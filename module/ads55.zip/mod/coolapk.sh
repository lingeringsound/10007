#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

#disable 代表禁用
#enable 代表启用
sate=enable

disable_list='
com.beizi.ad.AdActivity
com.beizi.ad.DownloadService
com.bytedance.applog.collector.Collector
com.bytedance.applog.migrate.MigrateDetectorActivity
com.bytedance.mapplog.collector.Collector
com.bytedance.novel.channel.NovelWebActivity
com.bytedance.novel.view.NovelReaderActivity
com.bytedance.sdk.dp.act.DPAuthorActivity
com.bytedance.sdk.dp.act.DPBrowserActivity
com.bytedance.sdk.dp.act.DPDrawPlayActivity
com.bytedance.sdk.dp.act.DPNewsDetailActivity
com.bytedance.sdk.dp.act.DPReportActivity
com.bytedance.sdk.dp.act.DPSearchActivity
com.bytedance.sdk.dp.act.DPWebcastActivity
com.bytedance.sdk.dp.core.privacy.DPPrivacySettingActivity
com.bytedance.sdk.open.douyin.ui.DouYinWebAuthorizeActivity
com.bytedance.sdk.openadsdk.activity.base.TTDelegateActivity
com.bytedance.sdk.openadsdk.activity.base.TTFullScreenExpressVideoActivity
com.bytedance.sdk.openadsdk.activity.base.TTFullScreenVideoActivity
com.bytedance.sdk.openadsdk.activity.base.TTMiddlePageActivity
com.bytedance.sdk.openadsdk.activity.base.TTPlayableWebPageActivity
com.bytedance.sdk.openadsdk.activity.base.TTRewardExpressVideoActivity
com.bytedance.sdk.openadsdk.activity.base.TTRewardVideoActivity
com.bytedance.sdk.openadsdk.activity.base.TTVideoScrollWebPageActivity
com.bytedance.sdk.openadsdk.activity.base.TTVideoWebPageActivity
com.bytedance.sdk.openadsdk.activity.base.TTWebPageActivity
com.bytedance.sdk.openadsdk.dislike.TTDislikeWebViewActivity
com.bytedance.sdk.openadsdk.multipro.aidl.BinderPoolService
com.bytedance.sdk.openadsdk.stub.activity.Stub_Activity
com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity
com.bytedance.sdk.openadsdk.stub.activity.Stub_SingleTask_Activity_T
com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity
com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Activity_T
com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Landscape_Activity
com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Portrait_Activity
com.bytedance.tea.crash.upload.CrashUploadService
com.coolapk.market.view.ad.dpsdk.DrawVideoFullScreenActivity
com.coolapk.market.view.splash.FullScreenAdActivity
com.heytap.msp.push.service.CompatibleDataMessageCallbackService
com.heytap.msp.push.service.DataMessageCallbackService
com.huawei.agconnect.core.ServiceDiscovery
com.huawei.agconnect.core.provider.AGConnectInitializeProvider
com.kepler.jd.sdk.KeplerBackActivity
com.kwad.sdk.api.proxy.VideoWallpaperService
com.kwad.sdk.api.proxy.app.AdSdkFileProvider
com.kwad.sdk.api.proxy.app.AdWebViewActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ChannelDetailActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$DeveloperConfigActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$EpisodeDetailActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity1
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity10
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity2
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity3
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity4
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity5
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity6
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity7
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity8
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivity9
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleInstance1
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleInstance2
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleTop1
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$FragmentActivitySingleTop2
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$GoodsPlayBackActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$KsTrendsActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ProfileHomeActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$ProfileVideoDetailActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$TubeDetailActivity
com.kwad.sdk.api.proxy.app.BaseFragmentActivity$TubeProfileActivity
com.kwad.sdk.api.proxy.app.DownloadService
com.kwad.sdk.api.proxy.app.FeedDownloadActivity
com.kwad.sdk.api.proxy.app.FileDownloadService$SeparateProcessService
com.kwad.sdk.api.proxy.app.FileDownloadService$SharedMainProcessService
com.kwad.sdk.api.proxy.app.KSRewardLandScapeVideoActivity
com.kwad.sdk.api.proxy.app.KsFullScreenLandScapeVideoActivity
com.kwad.sdk.api.proxy.app.KsFullScreenVideoActivity
com.kwad.sdk.api.proxy.app.KsRewardVideoActivity
com.kwad.sdk.api.proxy.app.ServiceProxyRemote
com.miui.zeus.mimo.sdk.ad.reward.RewardVideoAdActivity
com.qq.e.ads.ADActivity
com.qq.e.ads.DialogActivity
com.qq.e.ads.LandscapeADActivity
com.qq.e.ads.PortraitADActivity
com.qq.e.ads.RewardvideoLandscapeADActivity
com.qq.e.ads.RewardvideoPortraitADActivity
com.qq.e.comm.DownloadService
com.soundcloud.android.crop.CropImageActivity
com.ss.android.downloadlib.activity.JumpKllkActivity
com.ss.android.downloadlib.activity.TTDelegateActivity
com.ss.android.socialbase.appdownloader.DownloadHandlerService
com.ss.android.socialbase.appdownloader.RetryJobSchedulerService
com.ss.android.socialbase.appdownloader.view.DownloadTaskDeleteActivity
com.ss.android.socialbase.appdownloader.view.JumpUnknownSourceActivity
com.ss.android.socialbase.downloader.downloader.DownloadService
com.ss.android.socialbase.downloader.downloader.SqlDownloadCacheService
com.ss.android.socialbase.downloader.impls.DownloadHandleService
com.ss.android.socialbase.downloader.notification.DownloadNotificationService
com.tencent.tpns.mqttchannel.services.MqttService
'

for i in $disable_list 
do
pm $sate com.coolapk.market/$i >/dev/null 2>&1
done

function X_file() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function RE_file() {
	if test -e "$1"; then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}


find /data/user/*/com.coolapk.market /data/data/com.coolapk.market /data/media/*/Android/data/com.coolapk.market -iname "GDTDOWNLOAD" -type d -o -iname "tad_cache" -type d -o -iname "app_ad" -type d -o -iname "TTCache" -type d -o -iname "app_ad" -type d -o -iname "cachett_ad" -type d -o -iname "splash_image" -type d -o -iname "tt_tmpl_pkg" -type d -o -iname "com_qq_e_download" -type d -o -iname "pangle_com.byted.pangle" -type d 2>/dev/null | while read adfile ;do
	X_file $adfile 2>/dev/null 
done


if test -f "/data/system/ifw/com.coolapk.market.xml" -o -f "/data/system/ifw/com.coolapk.market$.xml" ;then
mkdir -p /data/system/ifw
	cp -rf $MODPATH/mod/com.coolapk.market.xml /data/system/ifw/com.coolapk.market.xml
		chmod 0700 /data/system/ifw/com.coolapk.market.xml
		chown -R system:system /data/system/ifw/com.coolapk.market.xml
test -f "/data/system/ifw/com.coolapk.market$.xml" && cp -rf /data/system/ifw/com.coolapk.market.xml "/data/system/ifw/com.coolapk.market$.xml"
fi

function lite_disable_comp(){
local IFS=$'\n'
local sate="$1"
local disable_list="
com.coolapk.market/com.ss.android.socialbase.downloader.notification.DownloadNotificationService
com.coolapk.market/com.tencent.tpns.mqttchannel.services.MqttService
com.coolapk.market/com.tencent.android.tpush.XGPushReceiver
com.coolapk.market/com.coolapk.market.receiver.TencentXGTPushReceiver
com.coolapk.market/com.tencent.android.tpush.XGVipPushKAProvider
com.coolapk.market/com.tencent.android.tpush.XGPushProvider
com.coolapk.market/com.tencent.android.tpush.service.XGVipPushService
com.coolapk.market/com.tencent.android.tpush.rpc.XGRemoteService
"
test -z $sate && sate="disable"
for i in $disable_list 
do
	pm "$sate" "$i" >/dev/null 2>&1
done
}

#小精简服务
#理论上"hide"貌似更好
lite_disable_comp "disable"
lite_disable_comp "hide" 




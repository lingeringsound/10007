id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
export PATH="/system/bin:$MODPATH/busybox:$PATH"

function Switch_ad_reward(){
local config_file="${MODPATH}/广告奖励.prop"
test ! -f "${file}" && echo "※“广告奖励文件丢失……" && return 0
local config_read="$(cat "${config_file}" | sed '/^#/d;/^[[:space:]]*$/d')"
if test "${1}" = "allow" ;then
	for i in ${config_read}
		do
	#禁用网址和子域名
			iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
	done
else
	for i in ${config_read}
		do
	#禁用网址和子域名
			iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
fi
}

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

Running_bin="${MODPATH}/mod/ads_monitor/ads_monitor"
Running_config="${MODPATH}/mod/ads_monitor/ads_monitor.prop"

test ! -f "${Running_bin}" && exit 0
killall -15 ads_monitor
source $MODPATH/mod/util_functions.sh
(
${Running_bin} -f "${Running_config}" >/dev/null 2>&1
) &

## 去广告
### 啥也不是？
#### 版本更新日志
### [源地址：如果有帮助，请您支持我一下😘！](https://lingeringsound.github.io/10007/ )
![赞赏码](https://lingeringsound.github.io/10007/donate/donate1.png)
#### [蓝奏云下载](https://keytoolazy.lanzn.com/b03j67j0f)，密码:`666`

- **说明**
 > 模块下载后有`README.md`文件，请自行阅读。
- ***模块原理说明***
 > hosts拦截域名，host相当于一个本地的dns，理论上并不会影响网速，甚至还能加快(屏蔽了不需要的ip)节省流量，缺点就是不支持屏蔽二级域名和支持通配符。
 >> chattr +i 命令能够锁定文件不被删除/修改，能够有效屏蔽毒瘤的sdk写入上传信息。
 >>> iptables具体去百度一下，用法很多，目前我用来屏蔽某些网站的次级域名，补充一些host的不足。
 >>>> pm(cmd package)，安卓上通用的禁用应用组件方式，屏蔽不必要的流氓行为。
- ***模块结构说明***
 > `mod` 脚本执行文件夹，每个脚本有不同的功能，脚本里有注释，不想执行该脚本，可以改后缀名为`bak`
 >> `配置.conf`(配置.prop) 在刷入前可以用 **[mt文件管理器](https://binmt.lanzoui.com/b01bivkzc)** 修改来自定义模块的一些功能。
 
| **Hosts引用链接** | 感谢各位大佬 |
| :-- | :-- |
| [大圣净化](https://github.com/jdlingyu/ad-wars) | ❤感谢！❤ |
| [yhost](https://github.com/VeleSila/yhosts) | ❤感谢！❤ |
| [Steven Black](https://github.com/StevenBlack/hosts) | ❤感谢！❤ |
| [oisd](https://oisd.nl/howto) | ❤感谢！❤ |
| [1024](https://github.com/Goooler/1024_hosts) | ❤感谢！❤ |
| [adhost](https://github.com/E7KMbb/AD-hosts) | ❤感谢！❤ |



>v6
 - 低估了酷安的恶心程度
>v7
 - 修复京东闲置回收无法打开的bug
>v8
 - 添加完整的卸载脚本uninstall.sh
>v9
 - 合并 **[NEO DEV Team](https://github.com/neodevpro/neodevhost)** 的广告拦截
>v11
 - 日常更新host
 - 支⃠持⃠在⃠线⃠更⃠新⃠(个屁)
>v12
 - 取消合并 **[NEO DEV Team](https://github.com/neodevpro/neodevhost)**
 - 更新酷安的禁用规则
 - 字节跳动的所有软件亦可正常使用，不再拦截如`今日头条`，`皮皮虾`，`抖音`。
>v13
 - 添加`ad`和`ads`域名拦截
>v14
 - 日常更新host
 - 添加`adnet`(chattr屏蔽)
>v15
 - 添加关键词`adsdk`的host屏蔽
>v16
 - 添加关键词`cnzz`的host屏蔽
>v17
 - 更新host规则
 - 更新酷安规则
>v18
 - 取消屏蔽`Flyme`
>v19
 - 取消屏蔽`QQ直播`
 - 取消屏蔽`X5内核下载`
>v20
 - 修复部分host误杀
>v21
 - 添加`doubleclick`和`googleads`域名的拦截
 - 修复`MIUI应用禁用组件`脚本的一些报错。
>v22
 - 尝试屏蔽`Flyme(MEIZU)`系统的一些广告，`Flyme`的用户可以反馈一下。
 - 添加`adapi`和`adsapi`相关域名屏蔽。
>v23
 - ①兄弟姐妹们，坏消息，我刚刚不小心删库了😨，之前抓的host没了😂。
 - ②好消息就是，对不起，没有好消息🙄③我凭借印象又抓了一遍，所以如果遇到误杀，请及时反馈🤔！
 - ③添加了**微信广告**的地址拦截。
>v24
 - ①添加`syndication`和`realsrv`域名下一些色色广告的屏蔽。
 - ②添加一些iptables规则
>v25
 - ①添加`weibo`域名下一些广告的屏蔽，有可能误杀，如果有，请及时反馈。
 - ②删除一些host，修复误杀。
>v26
 - 拦截更多`log`域名，尽量防止信息上传收集。
 - 从该版本起取消合并冲突的模块的host，改为禁用host，因为我发现其他模块的host问题也反馈到我这里来了，离谱。
>v27
 - ①合并保留广告版本，不再分开。
 - 模块压缩包里有`配置.conf`，你可以在里面选择是否保留广告奖励。
 - ②模块可以添加`自定义host`，你可以自己把规则填上去，填`域名`或者`127.0.0.1 域名`或者`0.0.0.0 域名`都可
 - ③取消屏蔽`api.swrve.com`和`doubleclick.net`下一些无效ip，资本家真的是太恶心人了。
 - 绝了各位，模块里不能有`中文.sh`🤔？
>v28 
 - 添加`banner`域名下广告的拦截。
 - 尝试修复部分用户出现`QQ邮箱`无法联网的问题。
>v29
 - ①取消`chattr`，改为全部`rm -rf`ad文件，因为酷安基本没人会`chattr -i 文件路径`，也不会有人拆脚本或者修改脚本执行。
 - ②以上修改酷安除外。
 - ③卸载重装酷安有问题的可以用 [Magisk 模块助手](https://keytoolazy.coding.net/s/56c32838-0c57-4dea-bb6e-35f420c8f2fe) → ***一些指令*** → ***解除文件(夹)锁定*** → ***输入`/data/data/com.coolapk.market`*** → ***执行*** → ***按照上诉再次输入`/sdcard/Android/com.coolapk.market`*** 。
>v30
 - ①修复一些脚本的问题，之前脑抽，自定义host全部写成127.0.0.1 忽略了重定向网站，不能怪我，毕竟是 **去广告** 模块😂。
 - ②添加一些蓝奏云重定向。
 - ③尝试修复王者荣耀活动页问题，声明：`不玩王者荣耀`，所以不能用，就卸载模块就完事了，我也不可能为了几个域名再去下个王者荣耀。
 - ④用爱发电很累，所以请用你正常的大脑看看 `README.md` ，学会自己拆包，修改。
>v31
 - `广告奖励.prop` 添加百度云的奖励视频排除。
 - 日常更新host
>v32
 - ①添加更多 `traceur` (追踪)屏蔽，防止用户隐私泄露
 - ②修复 ***欢乐升级*** 无法登陆的问题，或因此降低对 **腾讯** 下广告的屏蔽能力。
 - ③添加 ***优酷*** ***爱奇艺*** 广告屏蔽，若有问题，就后续不再屏蔽，因为太难维护了。
>v33
 - ①更新 **酷安** 规则
 - ②删除无效域名
 - ③更新 ***iptables*** 规则
>v34
 - ①可以在 `配置.conf` 决定是否chattr +i 广告文件，自动读取上一次模块原有的配置。
 - ②修复 **今日头条play版** 无法联网的问题。 
 - ③下次反馈应用请说明是play 版还是国内版，因为有时候这两个玩意差很多。
>v35
 - ①添加是否读取 `配置.conf` 的选项。
 - ②完善`custom.sh`，模块安装完后，可以自定义添加/删除一个文件内的host规则。
 - ③日常更新host，添加 `adsame` `mediav` `ad[[:digit:]]` `ad[[:alpha:]]` 下域名的拦截。
>v36
 - ①解除QQ微信小程序游戏的拦截。
 - ②添加 `admaster` 域名下广告的拦截。
>v37
 - 修复 **京东** 无法打开某些弹窗的问题[说实话，我觉得这些弹窗没有任何用处]。需要的自己加。
>v38
 - ①删掉一些误杀域名。
 - ②添加一些 `cookie` 拦截。
>v39
 - ①添加 `twitter` 域名下的拦截。
 - ②添加 `alimama` 和 `alicdn` 域名下的拦截。
>v40
 - 好消息，各位兄弟姐妹们，模块暂时停更了，这应该是最后一个版本。
 - 方法已经教过你们了，授人以鱼，不如授人以渔。
>v41
 - ①尝试解决上个版本的某些问题。
 - ②开始乱杀！！！！
>v42
 - ①诈尸更新！
 - ②取消屏蔽 ``小米快应用`` 
 - ③日常更新host
>v43
 - ①修复部分 `网易云音乐` 版本不能用使用的问题
 - ②各位大佬，这次我们玩点刺激的，请谨慎更新🤔，因为我这次直接合并了一个47m的host，地址：**[isod](https://oisd.nl/downloads)**
  - v44
 - ①删除 ***四万条*** 规则，持续更新中
 - ②更新iptables规则，过多的iptables 会影响网络性能，如果感觉不需要，可以在mod选择删除/手动修改/改后缀名的方式解除。
>v45
 - 日常更新host规则
>v46
 - 屏蔽 **有道云笔记** 开屏广告
 - 添加关键词 `push`
>v47
 - ①修复 **九游中心** 无法打开找回密码的bug
 - ②添加 `tracking` 关键词，防止隐私泄露。
 - ③添加 **腾讯** 部分广告屏蔽
>v48
 - ①更新链接转为coding
 - ②取消屏蔽 ***百度小程序*** 
 - ③更新部分规则
>v49
 - 合并 **[NEO DEV Team](https://github.com/neodevpro/neodevhost)** 的最新规则，可能会有误杀，请谨慎更新！
>v50
 - ①删除部分规则
 - ②添加关键词 `union` `ipinyou` `uc` 的拦截。
>v51
 - ①修复 `知乎视频` 无法打开的问题。
 - ②删除部分规则
>v52
 - ①删除关键词 `cdn` (因为国外网站误杀严重)
 - ②删除 ***一万条*** 规则。
 - ③微信小程序奖励 ***wxsnsdy.wxs.qq.com*** ***wxsnsdy.video.qq.com*** ，百度云视频奖励 ***nadvideo.baidu.com*** ***nadvideo2.baidu.com*** 这两个常用的你可以在模块刷入时自己在模块广告奖励.prop注释掉或者删掉，就可以获得奖励了。
>v53
 - ①添加关键词 `bcebos`
 - ②更新部分广告奖励，以及模块注释 ``微信奖励`` ``百度云视频`` ，因为用户较多，需要自己取消注释。
 - ③精简无用规则
>v54
 - ①取消屏蔽 `微视福利中心`
 - ②更新部分 ***cdn*** 域名规则
>v55
 - ①取消禁用 ``酷安`` 活动/内容提供器，因为新版酷安会疯狂检测组件导致cpu 占用异常(在100%～300%左右)。
 - ②更新部分规则
 - ③修复部分调用 `京东` api图片无法显示的问题。
>v56
 - 尝试屏蔽部分 **QQ浏览器** 的广告，虽然有可能不走hosts。
>v57
 - ①日常更新规则host规则
 - ②自己抓了一下 `京东` 的一些域名，有报错的，请反馈一下，我尽量修复。
>v58
 - ①更新部分 ```广告联盟``` 的域名
 - ②屏蔽了QQ浏览器小说的广告。
>v59
 - ①添加关键词 ``xunlei`` 相关域名屏蔽。
 - ②日常更新host规则
 - ③修复无法打开 ***腾讯支付*** 的问题。
>v60
 - ①添加文件chmod锁定
 - ②修复 ***酷安*** 无法下载应用的bug。
>v61
 - 日常更新广告联盟的hosts规则。
>v62
 - ①修复部分部分应用无法唤醒 ***淘宝*** 的问题，域名 ```acs4baichuan.m.taobao.com```
 - ②大面积删除部分域名，可能遇到部分广告再次出现，有的话可以反馈一下。
>v63
 - ①日常更新host规则
 - ②优化 ```pornhub``` 和 ```phncdn``` 误杀的问题，顺便去掉了一些广告。
>v64
 - ①更新 ***OPPO*** ***欢太*** 广告拦截。
 - ②修复上个卸载脚本不生效的问题。
 - ③修复 ***MIUI*** 安全中心无法校对流量话费的原因(之前可以校对，现在MIUI又换ip了)
>v65
 - ①修复 ``微信的知乎小程序`` 无法使用的问题。
 - ②精简host和iptables规则，将部分规则放入iptables。
>v66
 - ①倦了，和 ***v40*** 一样，将会停止更新一段时间。
 - ②删除部分可能误杀的域名
 - ③不要觉得这个模块可以去掉所有广告，因为现在 ***腾讯*** ***阿里*** 旗下很多应用他们可以不走hosts，而 ***豆瓣*** ***知乎*** ***酷安*** 之类的应用，也可以把广告直接放到主域名下，如果拦截了，软件也无法正常访问，就很淦😤！。
 - ④更新 `MIUI浏览器` 和 `UC浏览器` `夸克浏览器` 规则，可以用这个 ***[TAI](https://rapidtai.com/)*** 网址测试。
>v67
 - ①修复部分误杀
 - ②日常更新广告拦截
>v68
 - 禁用域名 `pingjs.qq.com` ，解决 **支付宝** 无法付款的问题。
>v69
 - ①日常更新拦截规则
 - ②修正部分bug 
>v70
 - 删除大量过期域名，如有广告复燃，可以尽快反馈给我。
>v71
 - ①屏蔽 `download.uc.cn` 防止网页劫持，自动下载夸克。
 - ②更新 **httpdns** 规则，防止部分劫持。
 - ③日常更广告新规则
>v72
 - ①修复部分 `阿里软件界面` 打不开的问题
 - ②更新部分 `视频软件` 的广告规则。
>v73
 - 修正部分误杀
>v74
 - 解决 **TIM** 文件文档无法打开的问题。
>v75
 - ①更正配置脚本的bug
 - ②日常更新规则
>v76
 - ①修复 支付宝体育服务无法点击的问题 `wgo.mmstat.com` 域名
 - ②日常更新规则
>v77
 - 修复 **小米天星金融** 和 **京东** 部分图片无法打开的问题。
>v78
 - 日常更新规则
>v79
 - 剔除过期域名
>v80
 - 修复部分误杀
>v81
 - 添加对 ```bilibili``` 的屏蔽
>v82
 - ①修复 ***脚本错误**
 - ②解决一些误杀
>v83
 - ①精简 ***哔哩哔哩***
 - ②更新一些规则
>v84
 - ①感谢 [@coolapk 星星是天空那片海](http://www.coolapk.com/u/3081182) ，删除域名 `cdn.bootcdn.net` 。
 - ②更新  **[NEO DEV Team](https://github.com/neodevpro/neodevhost)** 上游规则。
 - ③日常更新规则。
>v85
 - 批量抓取域名，有误杀问题，请及时反馈！
>v86
 - 继续添加域名，更新 **广告奖励*** 列表，部分广告奖励可以获得。
>v87
 - 修复部分误杀
>v88
 - ①更新广告规则
 - ②更新 **APP分享** 广告奖励屏蔽规则，可以自己注释然后获得广告奖励。
 - ③玄学屏蔽 **番茄小说** 广告。
>v89
 - ①添加部分 `1024` 网站的屏蔽。
 - ②修复了 **App分享** 部分软件图标不显示的问题
 - ③添加 **抖音** 软件的一些精简(模块目录/mod/aweme.sh)，模块内有些IFW规则(模块目录/mod/aweme.sh)，有需要的可以自己替换。
>v90
 - 修复一些误杀
 - 合并 `adaway` 上游规则。
>v91
 - ### **修复``配置文件``无法读取的致命错误!**
>v92
 - ①整理，删除过期/误杀域名。
 - ②日常更新Host。
>v93
 - ①修复皮皮虾部分内容无法刷新。域名: `dm.toutiao.com` 原因貌似需要经过这个验证才行。
 - ②尝试删除一些域名解决部分误杀。
 - ③日常批量抓取域名。
>v94
 - 剔除多余域名，更新广告规则。
>v95
 - ①添加对OPPO 手机系列的**com.opos.ads**，Commercial Service(广告服务)卸载
 - ②更新规则
>v96
 - ①去除**日志**相关域名，尝试解决部分设备出现因日志和信息采集而反复请求造成大量耗电的情况。
 - ②合并`adaway`上游规则。
>v97
 - ①修复**i茅台**无法加载在线界面的bug
 - ②应大众要求删除`hot.browser.miui.com`，虽然我没啥感觉，因为有无这个域名，MIUI浏览器下载都正常，只能说MIUI为了广告不干人事。
>v98
 - ①修复`360清理大师`插件无法下载的问题，只能说这个软件还有人用，真的强(快10年了)。
 - ②更新规则
 - ③删除部分规则
>v99
 - ①更新广告规则
 - ②修复`UC浏览器`头条文章，无法访问的问题。(顺便拦截了UC浏览器安全网址拦截)
>v100
 - ①更新广告规则
 - ②修复`夸克浏览器`文档插件无法下载的问题。
>v101
 - ①更新规则
 - ②剔除过期，无用域名。
>v102
 - ①更新规则
 - ②取消`dns.google.com`和`dns.alidns.com`屏蔽，不知道是哪个大佬提交的，让我迷惑了。
>v103
 - ①删除`quarklist`的源，解决部分误杀的问题。
 - ②更新规则。
>v104
 - ①更新`coolapk.sh`脚本
 - ②更新规则
>v106
 - ①修复一些域名误杀
 - ②更新规则
>v107
 - ①更新规则
 - ②取消屏蔽`v[[:digital:]]-novelapp.ixigua.com`(番茄小说)相关域名，有需要的可以在模块里找到自行添加。
>v108
 - 更新规则
>v109
 - 删除大量规则，可能有部分广告复燃，请及时反馈。
>v110
 - ①删除部分源，减少误杀范围。
 - ②我想了想，还是先停更吧，需要的可以自己退回旧版本。
>v112
 - 修复了部分地区QQ头像消失的问题，感谢酷友[咕噜咕噜滚下山](http://www.coolapk.com/u/11610988) 的测试。
 - 目前还是打算停更一段时间，一个人测试维护一年实在太累了。
>v114
 - 诈尸👻
 - ①删除对`zooplus`类的域名，这玩意好像没啥用
 - ②删除大量的无用的冲突的top域名。
 - ③去除对MIUI系统应用联网的请求。
>v115
 - 更新规则
>v116
 - 更新规则
 - 更改模块脚本
>v116
 - ①更新规则
 - ②更改模块脚本
>v117
 - ①更新穿山甲的一些ip
 - ②以后不再修bug，有bug自己抓包解决，不打算做成小白都能用的模块。
>v118
 - 更新模块脚本，防止出现删除`/data/data`目录的情况。
>v119
 - 合并 **[NEO DEV Team](https://github.com/neodevpro/neodevhost)** 上游规则。
>v120
 - 更新规则
>v123
 - 删除MIUI广告配置域名`sdkconfig.ad.xiaomi.com`，检测到MIUI会根据此域名对机型做出区别对待，例如系统广告/云控调度配置，很无语……
>v125
 - ①更新`喜马拉雅听书`部分广告域名。
 - ②添加新思路，限制ip域名的网速(`模块目录/mod/network_limit.sh`)，绕过软件自带的dns间接屏蔽了域名？也许……
>v126
 - 添加不替换hosts的选项。
>v127
 - ①修复脚本bug
 - ②更新hosts
>v128
 - ①修复脚本bug
 - ②更新hosts
>v129
 - 修复部分小米设备云服务和推送的问题。
>v132
 - 增加了一个没卵用的功能，开机会给一个通知……
 - 没事可以别刷
 - 不需要可以删除`模块目录/mod/notification.sh`解决。
>v133
 - 修复一些有关`Analysis`的问题。
>v138
 - ①修复酷安推送注册的问题，来自[酷安@ck388](http://www.coolapk.com/u/1347977)，感谢！具体我没经过测试，你们自己测试吧！
 - ②域名 `guid.tpns.tencent.com` `access1.tpns.tencent.com`
>v140
 - 因为 **[AdHost](https://github.com/E7KMbb/AD-hosts)** 常年不更新且误杀严重，顾删除。
>v150
>欢度春节
 - ***红梅含苞傲冬雪*** ***绿柳吐絮迎新春***
 - 祝各位 ***万*** 事**顺心顺意**，***身*** 体**健康长寿**，***家*** 人**平安团聚**！
 - **新年快乐**！
>151
 - QQ音乐广告奖励域名: `adstats.tencentmusic.com` `adsmind.gdtimg.com` `rpt.gdt.qq.com` `v.gdt.qq.com` `c.gdt.qq.com` `tmead.y.qq.com`
>152
 - 支持 `kernel su` 
>153
 - 更新**UC浏览器**和**夸克浏览器**网址拦截相关域名。
>154
 - 修复某些设备`OPPO 账号`无法登陆的问题，我在`Colors 11` 和 其他UI安装的`OPPO应用商店`测试了，可以登陆，如果后续还是不能，请自行抓包(毕竟我自己的设备有限)。
 - 修复 `Flyme` 应用商店游戏无法下载。
 - 感谢酷友的反馈，[@coolapk 我是真爱kun](http://www.coolapk.com/u/1742474) [@coolapk 何言与君识](http://www.coolapk.com/u/3477196)
>155
 - 更新`Google翻译`的可用域名
>v163
 - 可能是最后一次更新了，Gitee账号已经被官方屏蔽。
>v164
 - #### 解除小米ROM包下载限速，重定向至`123.6.13.6`和`23.202.34.138`。
 - #### 添加酷友的两个规则 不确定后续是否会误杀
 - #### @coolapk [营销号666](http://www.coolapk.com/u/554004)
````
127.0.0.1 dsp-x.jd.com
127.0.0.1 dsp-x.jd.com.gslb.qianxun.com
````
 - #### @coolapk [GreatYYH](http://www.coolapk.com/u/3241828)
```
127.0.0.1 api-cn.store.heytapmobi.com
```
>v170
 - #### 添加拦截蓝奏云剪切板写入，来自酷友
 - #### @coolapk[Aloazny](http://www.coolapk.com/u/27964501)
```
127.0.0.1 kl.67it.com
```
>v173
 - 修复王者荣耀部分问题(我也不打游戏，所以不知道问题大不大)
>v174
 - 修复部分京东领卷问题，不用京东，我也不知道为啥领不到。
```
m.jd.watbe.top
m.jd.watbc.top
```
>v175
 - 去除`omofun`广告。
>v178
 - 放行百度两个广告域名。
```
ecmb.bdimg.com
ecma.bdimg.com
```
>v179
 - 去除`快对`广告。
 - 感谢酷安@Aloazny提供的规则。
>v182
 - 添加了部分快手广告sdk拦截，不知道是否有副作用。
```
w1.gskwai.com
w2.gskwai.com
```
>v183
 - 记住有个SB叫[刺客边风](https://m.bilibili.com/space/21131684)！！！
```
127.0.0.1 black.qimo.ink
```
 - 缓存→`/storage/emulated/0/Android/data/tv.danmaku.bilibilihd/download` 移动到任意位置→设置→备份→清除数据→把`download`文件夹移动到`/storage/emulated/0/Android/data/tv.danmaku.bilibilihd/download`→设置所有者和文件夹权限777→重启→恢复。
>v184
 - ①域名`a0.app.xiaomi.com`改为iptables禁用
 - ②可用Magisk alpha的`action.sh`，选择放行或者禁用。
 - ③该域名影响MIUI云备份以及会上传应用列表给MIUI。
>v185
 - ①修复上个版本的`action.sh`代码写反的问题(理解下老年人……
 - ②广告奖励也改为`iptables`放行和禁用，用action也可执行。
>v187
 - 修复QQ音乐广告奖励问题。
>v188
 - 修复OPPO商店和主题问题，但同时也会出现开屏广告。
```
api-cn.store.heytapmobi.com
api-cn.theme.heytapmobi.com
```
>v190
 - 封锁几个漏网之鱼
>v191
>修复网易光遇 sky 登录
 - 感谢[@niani2](https://github.com/niani2)反馈
```
fp-upload.dun.163.com
```
>v193
 - 放行`click.discord.com`(还有一坨东西)，感谢[@Rainyin](https://github.com/Yinhono)反馈。
>v194
 - ①`api.ad.xiaomi.com`改为iptables禁用，感谢[@Say-Hi-bye](https://github.com/Say-Hi-bye)反馈，可以用action修改备份状态，直接执行`/data/adb/modules/GGAT_10007/action.sh`可反复切换禁用状态，可以用`anywhere`或者`xposed edge`执行命令。
 - ②添加放行白名单，支持`adashx.m.taobao.com` `@@||adashx.m.taobao.com^` `127.0.0.1 adashx.m.taobao.com` 的格式填入`放行白名单.prop`。
>v196
 - 优化模块逻辑和网络性能
>v197
 - 发现一个新方法，把一些应用广告的`sqlite数据库清空`，部分应用广告开屏广告就会消失几天。
>v199
 - `action`改为后台执行，避免卡顿感。
>v200
 - 放行`black.qimo.ink`，需要的可以自己添加到自定义hosts。
>v202
 - 有人下到盗版模块了😥，然后寄了，都说了群里的`脚本/模块`别乱刷，离谱得很，所以模块做了伪加密，我都给链接了，还能找到盗版，也是无语。
 - 需要自定义的，可以到`/data/adb/modules/GGAT_10007`修改，那几个配置文件，或者找个软件自己解压，重新打包，这是自保手段，说明二改和我无关。
>v203
 - 更新`biubiu加速器`的广告奖励。
>v204
 - 去除伪加密版本在[蓝奏云](https://keytoolazy.lanzn.com/b03j67j0f)，密码:`666`
 - 作业帮DNS改为`iptables`拦截。
>v205
 - 去除伪加密，**但是自己下了盗版被格机不要来找我**。
 - 添加一个`ads_monitor`，监控广告文件生成，不需要可以在`配置.prop`修改，或者删除`/data/adb/modules/GGAT_10007/mod/ads_monitor`。
 - 更新了部分应用开屏广告。
>v209
 - 尝试修复检验脚本的bug。
>v211
 - 更换文件检验方式，兼容老设备。
>v212
 - 优化`广告监视器`，文件不存在时会创建空文件并且设置权限为`000`，避免广告生成。
>v215
 - 修复老版酷安闪退问题(`删除了加固文件`)
 - 用`anythink`sdk的广告奖励有问题，不知道要不要放行，毕竟`iptables`规则太多也会影响网速。
>v216
 - 微信广告奖励域名添加，执行`/data/adb/modules/GGAT_10007/action.sh`可自由切换放行和禁用。
```
wxa.wxs.qq.com
wximg.wxs.qq.com
wxsmw.wxs.qq.com
```
>v217
 - 添加广告放行奖励脚本，在`/data/adb/modules/GGAT_10007/mod/广告奖励/reward.sh`，另一个是拦截脚本，可手动执行。
>v219
 - `kernel su`和`Apatch`会以`overlay-fs`方式挂载，不要再问环境问题了。
>v220
 - 放行网易云听歌统计。
 ```
 clientlog.music.163.com
 clientlog3.music.163.com
 ```
>v221
 - 优化`kernel su`挂载脚本。
>v222
 - 把`coolapk`的`/data/user/0/com.coolapk.market/databases`里面的穿山甲给扬了，byd看不到广告就天天往里面写日志，占了1个G了。
>v223
 - `kernel su`改为`mount --bind`挂载。
>v224
 - 优化`action.sh`速度。
>v225
 - 修复`起点阅读`无法放行广告的bug，不生效自己清理缓存也是可以的。
>v226
 - 非`kernel su`用户可以不更新，最后一次尝试修复`kernel su`挂载了，实在不行，我推荐用其他hosts管理器挂载，例如Adaway。
>v227
 - 懒得管什么`kernel su`漏不漏环境的问题了，照着[kernel su的官方文档](https://kernelsu.org/zh_CN/guide/faq.html)推荐的[模块](https://github.com/symbuzzer/systemless-hosts-KernelSU-module)抄了命令，不行？好用`mount --bind`？不行？读取不到`/sdcard`？6
 - 后来一看这个仓库，[bindhosts](https://github.com/backslashxx/bindhosts)，好家伙，有好几种挂载方式，`ksu_susfs`我也没用过，爱咋咋地吧，我还在`Android 10`呢，这原本也是magisk模块，`kernel su`咋样我也不管了。
>v229
 - 更新蓝奏云两个广告域名，蓝奏云剪切板劫持已经搞到内嵌脚本了，域名拦截不了了。
>v230
 - 更新部分埋`堆堆`广告，感谢GIthub@[samsunggithub](https://github.com/samsunggithub)反馈。
>v231
 - 恢复小米广告插件智能服务`com.miui.systemAdSolution`，改为文件禁止监视，因为有反馈说禁用会影响启动速度。
 - 什么，你说你已经卸载了？没事这里附上两个19和23年的版本，[小米智能服务](https://keytoolazy.lanzn.com/b007t52m1i)，密码：666。
>v232
 - 自行修改配置文件选择是否放行`小米智能服务`。
 - 修复`biubiu加速器`的快手sdk广告无法播放视频。
>v233
 - 修复QQ音乐开屏广告的问题😓，这玩意很离谱，`tmead.y.qq.com`和`tmeadcomm.y.qq.com`好像拦了，好像又没拦。
>v235
 - 修复`ads_monitor`的一个错误。
>v236
 - 修改广告奖励`hosts`挂载方式，模块hosts文件改为`mount --bind`，文件在`/data/adb/modules/GGAT_10007/Host`，原因是因为QQ音乐的广告用iptables无法屏蔽，网络性能应该会有改善？
 - 修复唯品会`api.union.vip.com`误杀。
>v237
 - 修复一个`QQ音乐`无法观看奖励的问题。
>v238
 - 添加一个mount_hosts挂载hosts文件，源码在模块里，可以自己修改。
 > 配置文件在/data/adb/modules/GGAT_10007/mod/mount_hosts/配置包名.prop，会自动读取顶层应用包名挂载hosts
 >> 优点就是①自动放行需要添加的广告应用②游戏之类的，把广告奖励自己在配置文件改成`recovery`后，网络波动应该不大了(不玩游戏，自测)③ksu/Apatch应该不会检测到挂载，因为用了`mount --bind`，可以用`cat /proc/mounts | grep hosts`查看挂载情况。
 >>> 缺点是有点**卡顿**，用了`dumpsys`命令获取顶层应用，耗电自测，默认不开启。

>v239
 - 优化`ads_monitor`和`mount_hosts`运行速度。
>v240
 - 添加`ads_monitor`白名单，防止修改`ads_monitor.prop`错误导致数据丢失。
>v241
 - 压缩`ads_monitor`和`mount_hosts`体积。
 - 更新hosts。
>v242
 - 修复`mount_hosts`在低安卓版本无法获取前台应用的bug。
>v243
 - 修复`ads_monitor`因`inotify`导致cpu占用过高和文件夹权限设置问题。
>v244
 - **damn bro！**，原谅我这愚蠢的小脑瓜，忘了还有32位(平板)这回事！
 - 没什么变化，就是多了几个arm/x86文件，但是不保证能用。
>v245
 - 忘记放源码了。
>v246
 - 修改`ads_monitor`对目录权限的判定。
 - 更新`hosts`。
>v247
 - 修复网易听歌统计。
```
127.0.0.1 clientlogdep.music.163.com
127.0.0.1 clientlogsf.music.163.com
```
>v249
 - 修复`hosts`合并不会到`all`和`reward`文件。
 - 更新[neodevhost](https://raw.githubusercontent.com/neodevpro/neodevhost/master/host)源。



SKIPMOUNT=false
function key_source(){
if test -e "$1" ;then
	source "$1"
	rm -rf "$1"
fi
}

test ! -f "$MODPATH/verify.sh" && abort "
 ____            
| __ ) _ __ ___  
|  _ \| '__/ _ \ 
| |_) | | | (_) |
|____/|_|  \___/ 
                 
窃钩者诛，窃国者侯，
世道不公，人心难测。
白日行藏，夜半出入，
鼠辈猖狂，天网恢恢。
善恶有报，非时不至，
劝君莫为，一时之利。
"

key_source $MODPATH/verify.sh
key_source $MODPATH/key.sh
key_source $MODPATH/update.sh
key_source $MODPATH/busybox.sh
key_source $MODPATH/host.sh
key_source $MODPATH/package_extra.sh
test -d $MODPATH/busybox && {
set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}


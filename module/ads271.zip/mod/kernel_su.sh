id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

wait_until_login() {
	# in case of /data encryption is disabled
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 1
	done
	# we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
	a="0"
	local test_file="/data/media/0/Android/data"
	while [ ! -e "${test_file}" ]; do
		a="$(($a + 1))"
		test "$a" = "3" && break
		sleep 1m
	done
}


function mount_set_perm_for_hosts(){
local target_file="${1}"
local dev_hosts="/dev/GGAT/${target_file##*/}"
test ! -f "${target_file}" && return
local system_host="/system/etc/hosts"
if test ! -f "${system_host}" ;then
for file in $(find /system/ /system_ext /vendor /product -iname 'hosts' -type f 2>/dev/null)
do
case "${file}" in
/system_ext* | /vendor* | /product*)
	system_host="/system"${file}""
	break
;;
/system*)
	system_host="${file}"
	break
;;
		esac
	done
fi
local perm_hosts="$(`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1` stat -c '%U %G %a' ${system_host} 2>/dev/null )"
local selinux_context="$(`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1` stat -Z ${system_host} 2>/dev/null | grep -i 'S_Context:' | sed 's/.*u:/u:/g' )"
test "${selinux_context}" = "" && selinux_context="u:object_r:system_file:s0"
set_perm "${target_file%/*}" ${perm_hosts} "${selinux_context}"
[[ ! -f "$dev_hosts" ]] && mkdir -p "$dev_hosts" && rm -r "$dev_hosts"
cp -rf "${target_file}" "$dev_hosts"
umount "${system_host}" >/dev/null 2>&1
mount --bind "${dev_hosts}" "${system_host}" >/dev/null 2>&1
}

wait_until_login

ping -c 1 -W 10 baidu.com || sleep 3m


if ping -c 1 -W 3 sanme2.lanzoui.com | grep -Eo '0\.0\.0\.0|127\.0\.0\.1' >/dev/null 2>&1 ;then
	Log_10007_dmesg "@10007:Host modtify" "i"
else
	Log_10007_dmesg "@10007:Host does not exist" "e"
	mount_set_perm_for_hosts "${MODPATH}/system/etc/hosts"
fi


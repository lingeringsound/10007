function Check_files(){
local Check_file="${MODPATH}/其他脚本/废弃脚本/file_list.sha256"
test ! -f "${Check_file}" && abort "
 ____            
| __ ) _ __ ___  
|  _ \| '__/ _ \ 
| |_) | | | (_) |
|____/|_|  \___/ 
                 
窃钩者诛，窃国者侯，
世道不公，人心难测。
白日行藏，夜半出入，
鼠辈猖狂，天网恢恢。
善恶有报，非时不至，
劝君莫为，一时之利。
"
echo -e "\n※ 检验文件中……\n"
for i in `cat "${Check_file}" | sed '/^#/d;/^[[:space:]]*$/d'`
do
file_path="$(echo "${MODPATH}/${i}" | cut -d'|' -f1 | sed 's|\/\/|\/|g')"
file_sha256="$(echo "${i}" | cut -d'|' -f2)"
if test ! -f "${file_path}" ;then
	echo -e "※[?] ${file_path##*/}文件缺失" 
	continue
fi
if ! (echo "${file_sha256}" "${file_path}" | sha256sum -c -s -) ;then
	echo -e "※ ${file_path##*/} 文件被修改\n※ 确保从官方渠道下载！"
	abort "
 _  ___   ___ _____ 
/ |/ _ \ / _ \___  |
| | | | | | | | / / 
| | |_| | |_| |/ /  
|_|\___/ \___//_/   
                    

 ____  _                         _     _                _ 
| __ )(_) __ _   _ __  _ __ ___ | |__ | | ___ _ __ ___ | |
|  _ \| |/ _\` | | '_ \| '__/ _ \| '_ \| |/ _ \ '_ \` _ \| |
| |_) | | (_| | | |_) | | | (_) | |_) | |  __/ | | | | |_|
|____/|_|\__, | | .__/|_|  \___/|_.__/|_|\___|_| |_| |_(_)
         |___/  |_|                                       

"
fi
	done
echo "※[✔] 完成！"
}

Check_files



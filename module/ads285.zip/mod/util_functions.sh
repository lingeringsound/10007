
id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"


function show_value() {
	local value=$1
	local file="$MODPATH/配置.prop"
	test ! -f "$file" && file="$MODPATH/配置.conf"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

#删除并且chattr +i 广告文件
function X_file() {
case $i in
"/data/user/"|"/data/user"|"/data/media/0/Android/data/"|"/data/media/0/Android/data"|"/data/data/"|"/data/data"|"/data"|"/data/"|"/data/media/0"|"/data/media/0/"|"/data/media/0/Downloa"|"/data/media/0/Download/"|"/data/media/0/Android"|"/data/media/0/Android/"|"/sdcard"|"/sdcard/"|"/sdcard/Download"|"/sdcard/Download/"|"/sdcard/Android"|"/sdcard/Android/"|"/storage"|"/storage/"|"/storage/emulated/0"|"/storage/emulated/0/"|"/storage/emulated/0/Download"|"/storage/emulated/0/Download/"|"/storage/emulated/0/Android"|"/storage/emulated/0/Android/"|"/"|"/*")
echo "你他娘的真是个人才！想把系统给格了？™"
exit 1
;;
*)
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
;;
esac
}

#恢复chattr +i锁定的文件，并且删除
function RE_file() {
case $i in
"/data/user/"|"/data/user"|"/data/media/0/Android/data/"|"/data/media/0/Android/data"|"/data/data/"|"/data/data"|"/data"|"/data/"|"/data/media/0"|"/data/media/0/"|"/data/media/0/Downloa"|"/data/media/0/Download/"|"/data/media/0/Android"|"/data/media/0/Android/"|"/sdcard"|"/sdcard/"|"/sdcard/Download"|"/sdcard/Download/"|"/sdcard/Android"|"/sdcard/Android/"|"/storage"|"/storage/"|"/storage/emulated/0"|"/storage/emulated/0/"|"/storage/emulated/0/Download"|"/storage/emulated/0/Download/"|"/storage/emulated/0/Android"|"/storage/emulated/0/Android/"|"/"|"/*")
echo "你他娘的真是个人才！想把系统给格了？™"
exit 1
;;
*)
	if test -e "$1"; then
		chattr =A "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
;;
esac
}

#删除并且用chmod权限锁定文件，效果比chattr要差
function mkdir_file() {
case $i in
"/data/user/"|"/data/user"|"/data/media/0/Android/data/"|"/data/media/0/Android/data"|"/data/data/"|"/data/data"|"/data"|"/data/"|"/data/media/0"|"/data/media/0/"|"/data/media/0/Downloa"|"/data/media/0/Download/"|"/data/media/0/Android"|"/data/media/0/Android/"|"/sdcard"|"/sdcard/"|"/sdcard/Download"|"/sdcard/Download/"|"/sdcard/Android"|"/sdcard/Android/"|"/storage"|"/storage/"|"/storage/emulated/0"|"/storage/emulated/0/"|"/storage/emulated/0/Download"|"/storage/emulated/0/Download/"|"/storage/emulated/0/Android"|"/storage/emulated/0/Android/"|"/"|"/*")
echo "你他娘的真是个人才！想把系统给格了？™"
exit 1
;;
*)
	if test -e "$1"; then
		chattr =A "$1"
		rm -rf "$1"
		mkdir -p "${1%/*}"
		touch "$1"
		chmod 000 "$1"
	fi
;;
esac
}

#日志记录
function Log_10007_dmesg(){
local log_type="${2}"
local text="${1}"
local time="$(date +'%F %T')"
case "${log_type}" in
W|w|warning|Warning)
	log_type="[W]"
;;
E|e|error|Error)
	log_type="[E]"
;;
I|i|info|Info)
	log_type="[I]"
;;
*)
	log_type="[?]"
;;
esac
test "$text" = "" && return
echo -e "${log_type}${time} ${text}"
echo -e "${log_type}${time} ${text}" >> /dev/kmsg
}

#调用zygisknext隐藏
function Zygisk_next_Re_hidden() {
export PATH="/data/adb/modules/zygisksu/bin:$PATH"
local state_file="/data/adb/zygisksu/denylist_enforce"
local policy_file="${state_file%/*}/denylist_policy"
local state_value=$(cat "${state_file}" 2>/dev/null)
local policy_value=$(cat "${policy_file}" 2>/dev/null)
[ "$(command -v zygiskd)" = "" ] && return

case "${policy_value}" in
 0) zygiskd denylist-policy default ;;
 1) zygiskd denylist-policy whitelist ;;
 *) zygiskd denylist-policy default ;;
esac

case "${state_value}" in
 1) zygiskd enforce-denylist enabled ;;
 2) zygiskd enforce-denylist just_umount ;;
 *) zygiskd enforce-denylist just_umount ;;
esac

if [ ! -f "${state_file}" ]; then
	zygiskd denylist-policy default
	echo "2" > "${state_file}"
	zygiskd enforce-denylist just_umount
fi

[ ! -f "${policy_file}" ] && zygiskd denylist-policy default
}

#调用系统通知notification
function notification_simulation(){
local title="${2}"
local text="${1}"
local author="${3}"
local timestamp=$(date +"%m-%d %H:%M")
local RANDOM_TAG="$(date +%s)_$RANDOM"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
test -z "${title}" && title='10007'
test -z "${text}" && text='您未给出任何信息'
test "`echo "${author}" | grep -E '^[0-9].*[0-9]$'`" = "" && author="2000"
text="$(echo "${text}" | sed "s/'/'\"'\"'/g")"; title="$(echo "${title}" | sed "s/'/'\"'\"'/g")"
local notification_msg="cmd notification post -t '${title}' -S messaging --conversation '${timestamp}' --message '${title}':'${text}' '${RANDOM_TAG}' '${title}' "
su "${author}" -c "${notification_msg}" >/dev/null 2>&1 \
 || su -lp "${author}" -c "${notification_msg}" >/dev/null 2>&1 \
 || su "shell" -c "${notification_msg}" >/dev/null 2>&1 \
 || su -c "${notification_msg}" >/dev/null 2>&1 \
 || eval "${notification_msg}" >/dev/null 2>&1
}

#查找其他prop值
function getprop_other_value() {
local prop_value="${1}"
local base_name="${prop_value#ro.}"
local base_name="${base_name#*.}"
local result=$(getprop "${prop_value}")
[ -n "${result}" ] && echo "${result}" && return
result=$(getprop "ro.$base_name")
[ -n "${result}" ] && echo "${result}" && return
[ "${base_name}" = "${prop_value}" ] && base_name="${prop_value#ro.}"
for i in system product vendor odm system_ext meizu oplus
do
	new_prop="ro.${i}.${base_name}"
	new_prop_market="ro.${i}.${base_name#*.}"
	result=$(getprop "${new_prop}")
	market_result=$(getprop "${new_prop_market}")
	[ -n "${result}" ] && echo "${result}" && return
	[ -n "${market_result}" ] && echo "${market_result}" && return
done
}


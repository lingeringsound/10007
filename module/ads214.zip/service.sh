#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
test -e $MODDIR/mod && {
	chmod -R 777 $MODDIR/mod
	until $(dumpsys deviceidle get screen) ;do
		sleep 10s
	done
	for i in $MODDIR/mod/*.sh ;do
		nohup $i >/dev/null 2>&1 &
	done
}

test -e $MODDIR/crond && {
chmod -R 777 $MODDIR/crond
crond -c $MODDIR/crond
}
#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

#ksu or apath
#来自(form) https://github.com/symbuzzer/systemless-hosts-KernelSU-module/
test -d "$MODDIR/worker" && {
modules_host="$(find "${MODDIR}" -iname 'hosts' -type f 2> /dev/null | head -n 1)"
system_hosts="$(find /system/ /system_ext /vendor /product -iname 'hosts' -type f 2> /dev/null | head -n 1)"
mount -t overlay -o lowerdir="${system_hosts%/*}",upperdir="${modules_host%/*}",workdir="$MODDIR/worker" KSU "${system_hosts%/*}"
}

test -e $MODDIR/mod && {
	chmod -R 777 $MODDIR/mod
	until $(dumpsys deviceidle get screen) ;do
		sleep 10s
	done
	for i in $MODDIR/mod/*.sh ;do
		nohup $i >/dev/null 2>&1 &
	done
}

test -e $MODDIR/crond && {
chmod -R 777 $MODDIR/crond
crond -c $MODDIR/crond
}




## 去广告
### 啥也不是？
- v6
 > 低估了某绿色软件的恶心程度
- v7
 > 修复京东闲置回收无法打开的bug
- v8
 > 添加完整的卸载脚本uninstall.sh
- v9
 > 合并`[NEO DEV Team](https://github.com/neodevpro/neodevhost)` 的广告拦截
- v11
 > 日常更新host
 > 支⃠持⃠在⃠线⃠更⃠新⃠(个屁)
 
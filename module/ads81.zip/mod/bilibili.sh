id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

source $MODPATH/mod/util_functions.sh



if test $(show_value "chattr锁定") == 是 ;then
	find /data/user/*/tv.danmaku.bili /data/data/tv.danmaku.bili /data/media/*/Android/data/tv.danmaku.bili -iname "res_cache" -type d 2>/dev/null | while read path ;do
		X_file "${path}"
	done
else 
	find /data/user/*/tv.danmaku.bili /data/data/tv.danmaku.bili /data/media/*/Android/data/tv.danmaku.bili -iname "res_cache" -type d 2>/dev/null | while read path ;do
		mkdir_file "${path}"
	done
fi

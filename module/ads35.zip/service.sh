#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
test -e $MODDIR/mod && {
	chmod -R 777 $MODDIR/mod
	until $(dumpsys deviceidle get screen) ;do
		sleep 5
	done
	for i in $MODDIR/mod/*.sh ;do
		$i 2> /dev/null
	done
}

test -e $MODDIR/crond && {
chmod -R 777 $MODDIR/crond
crond -c $MODDIR/crond
}
id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

Running_bin="${MODPATH}/mod/ads_monitor/ads_monitor"
Running_config="${MODPATH}/mod/ads_monitor/ads_monitor.prop"

test ! -f "${Running_bin}" && exit 0
pgrep -lf '/ads_monitor/ads_monitor' | grep -v "${0}" | while read pross
	do
	pid="$(echo "${pross}" | sed 's/[[:space:]].*//g')"
		kill -15 "${pid}"
done

source $MODPATH/mod/util_functions.sh

if test -f "${Running_config}" ;then
	for i in `cat "${Running_config}" | sed '/#/d;/^[[:space:]]*$/d'`
		do
			if test -d "${i}" ;then
				mkdir_file "${i}"
			fi
	done
fi

(
${Running_bin} -f "${Running_config}" >/dev/null 2>&1
) &

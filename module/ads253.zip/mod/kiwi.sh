#/system/bin/sh
#屏蔽虎牙
#iptables -F
iptables -A OUTPUT -m string --string "livewebbs2.msstatic.com" --algo bm --to 65535 -j DROP

#恢复
#iptables -D OUTPUT -m string --string "livewebbs2.msstatic.com" --algo bm --to 65535 -j DROP

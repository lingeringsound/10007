package_name=(
com.xiaomi.ab
com.miui.analytics
com.opos.ad
com.opos.ads
)

function disable_apps(){
local package="${1}"
test "${2}" = "" && return 0
if test "${2}" = "disable" ;then
	pm disable "${package}" >/dev/null 2>&1
	pm hide "${package}" >/dev/null 2>&1
else
	pm unhide "${package}" >/dev/null 2>&1
	pm enable "${package}" >/dev/null 2>&1
fi
}


for i in ${package_name[@]}
do
	disable_apps "${i}" "disable"
done

#恢复小米com.miui.systemAdSolution的启动
disable_apps "com.miui.systemAdSolution"

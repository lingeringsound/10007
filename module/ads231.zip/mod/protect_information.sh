id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

protect_information_apps=(
#酷安
/data/user/*/com.coolapk.market/shared_prefs/umeng*.xml
/data/user/*/com.coolapk.market/shared_prefs/tt_*.xml
/data/user/*/com.coolapk.market/shared_prefs/pangle_*.xml
/data/user/*/com.coolapk.market/shared_prefs/mobads_*.xml
/data/user/*/com.coolapk.market/shared_prefs/ksadsdk_*.xml
/data/user/*/com.coolapk.market/shared_prefs/kssdk_*.xml
/data/user/*/com.coolapk.market/shared_prefs/jadyunsdk.xml
/data/user/*/com.coolapk.market/shared_prefs/com.qq.e.*.xml
/data/user/*/com.coolapk.market/shared_prefs/beizisdk_*.xml
/data/user/*/com.coolapk.market/shared_prefs/anythink_*.xml
/data/user/*/com.coolapk.market/shared_prefs/anythinkadx_*.xml
/data/user/*/com.coolapk.market/shared_prefs/auth_sdk_device.xml
/data/user/*/com.coolapk.market/shared_prefs/auth_shared.xml
/data/user/*/com.coolapk.market/shared_prefs/bd_sp_*.xml
/data/user/*/com.coolapk.market/shared_prefs/kepler_public.xml
/data/user/*/com.coolapk.market/shared_prefs/yd_share_data.xml
/data/user/*/com.coolapk.market/shared_prefs/pdd_*.xml
)

#for target in ${protect_information_apps[@]}
#do
#	mkdir_file "${target}"
#done


ARCH_KEY="$(uname -m 2>/dev/null )"
ARCH_KEY_Prop="$(getprop ro.product.cpu.abi)"
[[ "${ARCH}" == "" ]] && ARCH="${ARCH_KEY_Prop}"
[[ "${ARCH_KEY_Prop}" == "" ]] && ARCH="${ARCH_KEY}"

case "${ARCH}" in
aarch64|arm64)
mv -f "${MODPATH}/mod/ads_monitor/ads_monitor_arm64" "${MODPATH}/mod/ads_monitor/ads_monitor"
mv -f "${MODPATH}/mod/mount_hosts/mount_hosts_arm64" "${MODPATH}/mod/mount_hosts/mount_hosts"
;;
armv7l|arm)
mv -f "${MODPATH}/mod/ads_monitor/ads_monitor_arm32" "${MODPATH}/mod/ads_monitor/ads_monitor"
mv -f "${MODPATH}/mod/mount_hosts/mount_hosts_arm32" "${MODPATH}/mod/mount_hosts/mount_hosts"
;;
i686|x86)
mv -f "${MODPATH}/mod/ads_monitor/ads_monitor_x86" "${MODPATH}/mod/ads_monitor/ads_monitor"
mv -f "${MODPATH}/mod/mount_hosts/mount_hosts_x86" "${MODPATH}/mod/mount_hosts/mount_hosts"
;;
x86_64|x64)
mv -f "${MODPATH}/mod/ads_monitor/ads_monitor_x86_64" "${MODPATH}/mod/ads_monitor/ads_monitor"
mv -f "${MODPATH}/mod/mount_hosts/mount_hosts_x86_64" "${MODPATH}/mod/mount_hosts/mount_hosts"
;;
*)
echo "- 不支持的构架！"
rm -rf "${MODPATH}/mod/ads_monitor"
rm -rf "${MODPATH}/mod/mount_hosts"
return 0
;;
esac

rm -rf ${MODPATH}/mod/mount_hosts/mount_hosts_* \
${MODPATH}/mod/ads_monitor/ads_monitor_* 2>/dev/null

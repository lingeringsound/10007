function notification_simulation(){
local title="${2}"
local text="${1}"
local author="${3}"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
	test -z "${title}" && title='10007'
		test -z "${text}" && text='您未给出任何信息'
	test "`echo "${author}" | grep -E '^[0-9].*[0-9]$'`" = "" && author="2000"
su -lp "${author}" -c "cmd notification post -S messaging --conversation '${title}' --message '${title}':'${text}' 'Tag' '$(echo $RANDOM)' " >/dev/null 2>&1 &
}

function Host_info(){
local MODPATH="${0%/*}"
local host_file=`find "${MODPATH}" -iname "hosts" -type f | head -n 1`
test "${host_file}" = "" && host_file="/system/etc/hosts"
local host_count="$(cat $host_file | sed '/^#/d;/^[[:space:]]*$/d' | wc -l)"
if test "$host_count" -ge "500000" ;then 
	local sate="网络存在一定延迟"
elif test "$host_count" -ge "50000" ;then 
	local sate="网络小幅度延迟"
elif test "$host_count" -lt "50000" ;then 
	local sate="网络基本无影响"
fi
echo "当前Host数量: ${host_count}，${sate}"
#echo "${host_count}"
}

function reset_modules(){
test -f "${0%/*}/module.prop" && return 0
cat << KEY > "${0%/*}/module.prop"
id=GGAT_10007
name=去广告
version=橴炫v184
versionCode=185
author=@coolapk 10007
description=host+chattr+pm+iptables去广告，host规则来自网络+本人手动抓取。$(Host_info)
updateJson=https://lingeringsound.github.io/10007/update.json
KEY
}

function refresh_information(){
local magisk_package
if magisk -v >/dev/null 2>&1 ;then
case "$(pm list package | grep -Eo 'io\.github\.huskydg\.magisk|io\.github\.vvb2060\.magisk|com\.topjohnwu\.magisk' )" in
com.topjohnwu.magisk)
	magisk_package="com.topjohnwu.magisk"
;;
io.github.vvb2060.magisk)
	magisk_package="io.github.vvb2060.magisk"
;;
io.github.huskydg.magisk)
	magisk_package="io.github.huskydg.magisk"
;;
*)
	magisk_package=`magisk --sqlite "SELECT value FROM strings where key='requester'" | cut -d'=' -f2`
;;
esac
local top_app="$(dumpsys window | sed '/mCurrentFocus/!d;s/.*[[:space:]]//g;s/\/.*//g')"
	if [[ "${top_app}" = "${magisk_package}" ]];then
		am start "intent:#Intent;action=;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=${magisk_package}/com.topjohnwu.magisk.ui.MainActivity;end"
	fi
fi
}



(
test ! -f "${0%/*}/backup.prop" && cp -rf "${0%/*}/module.prop" "${0%/*}/backup.prop"

flag_file="${0%/*}/xiaomi_backup"

if test ! -f "${flag_file}" ;then
	echo "[✔]已经放行a0.app.xiaomi.com和广告奖励，注意放行可能会泄露已安装应用给小米，风险自行承担。" 
	echo -e "                                  
       _ _               
  __ _| | | _____      __
 / _\` | | |/ _ \ \ /\ / /
| (_| | | | (_) \ V  V / 
 \__,_|_|_|\___/ \_/\_/  
                         
"
	#云备份
	test -f "${0%/*}/mod/a0.app.xiaomi.com.sh" && {
	source "${0%/*}/mod/a0.app.xiaomi.com.sh"
		Xiaomi_backup "allow"
	touch "${flag_file}"
	} || echo "${0%/*}/mod/a0.app.xiaomi.com.sh丢失！"
	#广告奖励
	test -f "${0%/*}/mod/ad_reward.sh" && {
		source "${0%/*}/mod/ad_reward.sh"
		Switch_ad_reward "allow"
		if test "$(which -a iptables-save)" != "" ;then
			if test "$(iptables-save | grep 'api-access.pangolin-sdk-toutiao.com')" != "" ;then
				chmod 0777 "${0%/*}/mod/广告奖励/reward.sh"
				"${0%/*}/mod/广告奖励/reward.sh"
			fi
		else
			if test "$(iptables -L | grep 'api-access.pangolin-sdk-toutiao.com')" != "" ;then
				chmod 0777 "${0%/*}/mod/广告奖励/reward.sh"
				"${0%/*}/mod/广告奖励/reward.sh"
			fi
		fi
	} || echo "${0%/*}/mod/ad_reward.sh丢失！"
	
	notification_simulation "已经放行a0.app.xiaomi.com和广告奖励，注意放行可能会泄露已安装应用给小米，风险自行承担。" "放行MIUI云备份" "去广告模块"
	sed -i 's/description=.*/description=☞当前以放行MIUI云备份和广告奖励，注意放行a0.app.xiaomi.com，可能会泄露已安装应用给小米。☜\n/g' "${0%/*}/module.prop"
	refresh_information
else
	echo "[✘]已禁止访问a0.app.xiaomi.com和广告奖励域名，保护您的安全。"
	echo -e "                                   
 _     _            _    
| |__ | | ___   ___| | __
| '_ \| |/ _ \ / __| |/ /
| |_) | | (_) | (__|   < 
|_.__/|_|\___/ \___|_|\_\
                         
"
	#云备份
	test -f "${0%/*}/mod/a0.app.xiaomi.com.sh" && {
	source "${0%/*}/mod/a0.app.xiaomi.com.sh"
		Xiaomi_backup
	rm -rf "${flag_file}"
	} || echo "${0%/*}/mod/a0.app.xiaomi.com.sh丢失！"
	#广告奖励
	test -f "${0%/*}/mod/ad_reward.sh" && {
		source "${0%/*}/mod/ad_reward.sh"
		Switch_ad_reward
	} || echo "${0%/*}/mod/ad_reward.sh丢失！"
	
	notification_simulation "已禁止访问a0.app.xiaomi.com和广告奖励域名，保护您的安全。" "禁用MIUI云备份" "去广告模块"
	cp -rf "${0%/*}/backup.prop" "${0%/*}/module.prop"
	refresh_information
fi

reset_modules
test -f "${0%/*}/mod/ads_monitor.sh" && "${0%/*}/mod/ads_monitor.sh" & >/dev/null 2>&1 &
test -f "${0%/*}/mod/ad.sh" && "${0%/*}/mod/ad.sh" & >/dev/null 2>&1 &
) &







list="
ikhgg.snalkdl.top
www.googleadservices.com
googleadservices.com
"

for i in $list ;do
iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done 


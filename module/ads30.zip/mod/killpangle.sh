id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

function X_file() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function RE_file() {
	if test -e "$1"; then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}


find /data/user /data/data /data/media/*/Android/data -iname "GDTDOWNLOAD"  -o -iname "app_adnet"  -o -iname "tad_cache"  -o -iname "app_ad"  -o -iname "TTCache"  -o -iname "app_ad"  -o -iname "cachett_ad"  -o -iname "tt_tmpl_pkg"  -o -iname "com_qq_e_download"  -o -iname "pangle_com.byted.pangle"  2>/dev/null | while read adfile ;do
RE_file "${adfile}" 2>/dev/null
done
#!/system/bin/sh

if test "$(getprop ro.miui.ui.version.name)" != "" ;then 
	settings put global passport_ad_status OFF
fi

#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

function X_file() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

function RE_file() {
	if test -e "$1"; then
		chattr -i "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}

find /data/user/*/com.coolapk.market /data/data/com.coolapk.market /data/media/*/Android/data/com.coolapk.market -iname "tt_mediation_open_sdk.db" -type f -o -iname "GDTDOWNLOAD" -type d -o -iname "tad_cache" -type d -o -iname "app_ad" -type d -o -iname "TTCache" -type d -o -iname "app_ad" -type d -o -iname "cachett_ad" -type d -o -iname "splash_image" -type d -o -iname "tt_tmpl_pkg" -type d -o -iname "com_qq_e_download" -type d -o -iname "pangle_com.byted.pangle" -type d 2>/dev/null | while read adfile ;do
	X_file $adfile 2>/dev/null 
done




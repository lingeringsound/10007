id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

source $MODPATH/mod/util_functions.sh

#番茄阅读插件
#-o -iname "plugins" -type d 

find /data/user/*/com.dragon.read /data/data/com.dragon.read /data/media/*/Android/data/com.dragon.read -iname "offlineX" -type d 2>/dev/null | while read adfile
do
	mkdir_file $adfile 2>/dev/null 
done


function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
MOCK_LOCATION
MONITOR_HIGH_POWER_LOCATION
FINE_LOCATION
MONITOR_LOCATION
WRITE_CLIPBOARD
READ_CLIPBOARD
WAKE_LOCK
WRITE_EXTERNAL_STORAGE
READ_PHONE_STATE
SYSTEM_ALERT_WINDOW
TOAST_WINDOW
"
for ops in $list 
do
	cmd appops set $package $ops $action
done
}

deny_appops "com.dragon.read" "ignore"

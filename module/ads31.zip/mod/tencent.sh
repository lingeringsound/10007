export PATH=$(magisk --path)/.magisk/busybox:$PATH


#恢复chattr +i锁定的文件，并且删除
function X_FILE_RE (){
	if test -e "$1" ;then
		chattr -i "$1"
		rm -rf "$1"
	fi
}

#删除并且chattr +i 广告文件
function X_FILE_DIR (){
	if test -e "$1" ;then
	chattr -i -A -a -u "$1"
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

#运行删除腾讯监视文件，没有禁止写入
#如有需要就自己把X_FILE_RE改成X_FILE_DIR
#注意如果禁止写入，请禁用MIUI 手机管家的任何引擎。
#如腾讯杀毒引擎，腾讯清理引擎，不然就会引起相关组件
#cpu 占用100%
find /data/media /data/data /data/user /data/user_de -iname "turing.dat" -type f -o -iname ".tmfs" -type d 2>/dev/null | while read path ;do
X_FILE_RE "${path}"
done
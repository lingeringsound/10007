#!/system/bin/sh

dir="${0%/*}"
MODPATH="${dir%/*}"

export PATH=$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH

source $MODPATH/mod/util_functions.sh


function show_value() {
	local value=$1
	local file="$MODPATH/配置.prop"
	test ! -f "$file" && file="$MODPATH/配置.conf"
	cat "$file" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

if test "$( show_value '替换hosts' )" != "是" ;then
	find $MODPATH/system -iname "hosts" -type f -exec rm -rf {} \; 2>/dev/null
	find $MODPATH/system -type d -empty -exec rm -rf {} \; 2>/dev/null
fi




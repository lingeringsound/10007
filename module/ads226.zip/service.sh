#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

function overlay_system_hosts(){
local modules_host="$(find "${MODDIR}" -iname 'hosts' -type f 2>/dev/null | head -n 1)"
local modules_host_folder="${modules_host%/*}"
local system_hosts="$(echo "${modules_host}" | sed "s|${MODDIR}||g")"
local system_hosts_folder="${system_hosts%/*}"
#ksu or apath
#来自(form) https://github.com/symbuzzer/systemless-hosts-KernelSU-module/
if test -d "$MODDIR/worker" ;then
if test "${modules_host_folder}" = "" ;then
	echo "[!] hosts文件丢失！"
else
#overlay-fs 挂载
	if [[ "$(find /data/adb -maxdepth 1 -iname "ksu" -type d | head -n 1)" != "" ]];then
		target_overlay_name="KSU"
	elif [[ "$(find /data/adb -maxdepth 1 -iname "ap" -type d | head -n 1)" != "" ]];then
		target_overlay_name="APatch"
	else
		target_overlay_name="overlay"
	fi
		mount -t overlay -o "lowerdir=${system_hosts_folder},upperdir=${modules_host_folder},workdir=$MODDIR/worker" "${target_overlay_name}" "${system_hosts_folder}" >/dev/null 2>&1
fi
#mount --bind 挂载
	if test -f "${system_hosts}" ;then
		grep -q "@coolapk" "${system_hosts}" || mount --bind "${modules_host}" "${system_hosts}"
	else
		echo "系统hosts未找到或者脚本错误 ${system_hosts}"
	fi
fi
}

#挂载systemless hosts
(overlay_system_hosts &)
#设置action.sh权限
test -f "${MODDIR}/action.sh" && chmod 0755 "${MODDIR}/action.sh"

test -e $MODDIR/mod && {
	chmod -R 777 $MODDIR/mod
	until $(dumpsys deviceidle get screen) ;do
		sleep 10s
	done
	for i in $MODDIR/mod/*.sh ;do
		nohup $i >/dev/null 2>&1 &
	done
}

test -e $MODDIR/crond && {
chmod -R 777 $MODDIR/crond
crond -c $MODDIR/crond
}




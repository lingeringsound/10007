id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
local_MODPATH="/data/adb/$Magisk_mod/$id"
conf_file="${MODPATH}/配置.conf"
target_file="$local_MODPATH/配置.conf"

function show_value() {
	local value=$1
	local file="${2}"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

function replace_value() {
	local name="${1}"
	local value="$(show_value "${name}" "{target_file}" )"
	local file="${2}"
	sed -i "s|^.*$name=.*|$name=$value|g" $file
}


if test -e $target_file ;then
	if test $(show_value "读取配置" "${conf_file}" ) == 否 ;then
		return 0
	else
		replace_value "chattr锁定" "$conf_file"
		replace_value "合并host" "$conf_file"
		replace_value "广告奖励" "$conf_file"
	fi
fi


